/* RX-ACADEMY v2 — بازطراحی کامل ناوبری و تجربهٔ کاربری
   شش تب: آموزش · سنجش · داروخانه · نسخه‌خوان · پیشخوان · تنظیمات
   صفر وابستگی خارجی · آفلاین‌اول · راست‌چین */
'use strict';

/* ---------------- dom helpers ---------------- */
const $ = (s, el = document) => el.querySelector(s);
const h = (tag, attrs = {}, ...kids) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined && v !== false) el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const faNum = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const pct = (a, b) => b ? Math.round((a / b) * 100) : 0;
const norm = s => String(s || '').toLowerCase();

/* آیکون‌های خطی (بدون فونت/وابستگی) */
const IC = {
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>', // RTL: اشاره به راست = بازگشت
  home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5"/><path d="M5.5 9.5V21h13V9.5"/><path d="M9.5 21v-6h5v6"/></svg>',
  book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5V5.5"/><path d="M8 7h8M8 11h6"/></svg>',
  quiz: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="18" rx="3"/><path d="M9 8.5h6M9 12h6"/><path d="m8.7 15.8 1.6 1.6 3-3.2"/></svg>',
  pharma: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><rect x="3.2" y="9" width="17.6" height="6.5" rx="3.25" transform="rotate(-35 12 12)"/><path d="M9.6 8.6l4.8 6.8"/></svg>',
  rx: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h7a4 4 0 0 1 0 8H6z"/><path d="M6 3v18"/><path d="M10.5 11 18 21"/><path d="M18 14l-7 7"/></svg>',
  gear: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3.9a7 7 0 0 0-2-1.2L14.2 3H9.8l-.4 2.6a7 7 0 0 0-2 1.2l-2.3-.9-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-.9a7 7 0 0 0 2 1.2l.4 2.6h4.4l.4-2.6a7 7 0 0 0 2-1.2l2.3.9 2-3.4-2-1.5c.06-.4.1-.8.1-1.2z"/></svg>',
  calc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="3" width="14" height="18" rx="2.5"/><path d="M8.5 7.5h7"/><path d="M8.5 12h.01M12 12h.01M15.5 12h.01M8.5 15.5h.01M12 15.5h.01M15.5 15.5h.01"/></svg>',
  terms: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6h16M4 10h16M4 14h10M4 18h7"/></svg>',
  esc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2.5 20h19z"/><path d="M12 9.5v4.5"/><path d="M12 17.2h.01"/></svg>',
  err: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5V13"/><path d="M12 16.6h.01"/></svg>',
  tips: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 18h5"/><path d="M10.5 21h3"/><path d="M12 3a6 6 0 0 1 3.5 10.9c-.8.6-1.5 1.2-1.5 2.1h-4c0-.9-.7-1.5-1.5-2.1A6 6 0 0 1 12 3z"/></svg>',
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.8-3.8"/></svg>',
  lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="10.5" width="14" height="10" rx="2.5"/><path d="M8 10.5V7.8a4 4 0 0 1 8 0v2.7"/></svg>',
  check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="m4.5 12.5 5 5L19.5 7"/></svg>',
  play: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M7 4.8v14.4L19 12z"/></svg>',
  doc: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4"/><path d="M10 12h5M10 16h5"/></svg>',
  sort: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h12M4 12h9M4 17h6"/><path d="m17 10 3 3-3 3"/></svg>',
  chev: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"><path d="M14 5l-7 7 7 7"/></svg>',
};
const ic = (name, cls) => h('span', { html: IC[name], class: 'icn' + (cls ? ' ' + cls : '') });

const DISCLAIMER = 'این برنامه یک منبع آموزشی برای یادگیری نسخه‌خوانی و کار در داروخانه است؛ نه راهنمای درمان و نه جایگزین قضاوت داروساز یا پزشک. هیچ‌گاه بر پایهٔ محتوای این برنامه برای بیمارِ مشخص تصمیم نگیرید. در هر مورد تردید، به داروساز مسئول ارجاع دهید و آخرین بخشنامه‌های رسمی را ملاک قرار دهید.';

/* ---------------- تنظیمات کاربر ---------------- */
const SET_KEY = 'rx-academy-settings-v1';
const settings = (() => {
  let d = {};
  try { d = JSON.parse(localStorage.getItem(SET_KEY) || '{}'); } catch (e) { d = {}; }
  d.theme ??= 'system';               // light | dark | system
  d.fontScale ??= 1;                  // 1 | 1.12 | 1.25
  d.density ??= 'comfortable';        // comfortable | compact
  d.study ??= {}; d.study.mode ??= 'sequential';  // sequential=پیش‌فرض | free
  d.study.showProgress ??= true;
  d.study.autoResume ??= true;
  d.quiz ??= {}; d.quiz.random ??= false;        // تصادفی فقط داخل درس؛ پیش‌فرض خاموش
  const save = () => { try { localStorage.setItem(SET_KEY, JSON.stringify(d)); } catch (e) {} };
  return {
    get: () => d, save,
    set(patch) { Object.assign(d, patch); save(); applyLook(); },
    reset() { d = { theme: 'system', fontScale: 1, density: 'comfortable', study: { mode: 'free', showProgress: true, autoResume: true }, quiz: { mode: 'free' } }; save(); applyLook(); },
  };
})();
const mqDark = () => (typeof matchMedia === 'function'
  ? matchMedia('(prefers-color-scheme: dark)')
  : { matches: false, addEventListener() {}, addListener() {} });
function applyLook() {
  const s = settings.get();
  const dark = s.theme === 'dark' || (s.theme === 'system' && mqDark().matches);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-density', s.density);
  document.documentElement.style.setProperty('--font-scale', String(s.fontScale));
}

/* ---------------- ذخیرهٔ پیشرفت (همان کلید قبلی + فیلدهای جدید) ---------------- */
const STORE_KEY = 'rx-academy-progress-v1';
const store = (() => {
  let d = {};
  try { d = JSON.parse(localStorage.getItem(STORE_KEY) || '{}'); } catch (e) { d = {}; }
  d.bookRead ??= {}; d.quiz ??= {}; d.quizDone ??= {}; d.lastPage ??= null; d.lastDrug ??= null; d.scnDone ??= {}; d.lastQuiz ??= null;
  return {
    get: () => d,
    save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(d)); } catch (e) {} },
    markPage(id, ctx) { d.bookRead[id] = 1; if (ctx) d.lastPage = { ...ctx, ts: Date.now() }; this.save(); },
    lessonReadCount(lesson) { return lesson.page_ids.filter(p => d.bookRead[p]).length; },
    lessonDone(lesson) { return this.lessonReadCount(lesson) >= lesson.page_ids.length; },
    quizStats(ch) { return d.quiz[ch] ??= { attempts: 0, answered: 0, correct: 0, best: 0 }; },
    recordQuiz(ch, answered, correct) {
      const s = this.quizStats(ch);
      s.attempts++; s.answered += answered; s.correct += correct;
      s.best = Math.max(s.best, answered ? pct(correct, answered) : 0);
      d.lastQuiz = { ch, ts: Date.now() };
      this.save();
    },
    setLastDrug(id) { d.lastDrug = id; this.save(); },
    setScn(id, v) { v ? d.scnDone[id] = 1 : delete d.scnDone[id]; this.save(); },
    clearStudy() { d.bookRead = {}; d.lastPage = null; this.save(); },
    clearQuiz() { d.quiz = {}; d.lastQuiz = null; this.save(); },
  };
})();

/* ---------------- لایهٔ داده (مانیفست‌محور، بدون سقف) ---------------- */
const cache = {};
async function jfetch(url) {
  if (cache[url]) return cache[url];
  const r = await fetch(url);
  if (!r.ok) throw new Error('خطا در دریافت ' + url);
  const j = await r.json();
  cache[url] = j;
  return j;
}
const API = {
  manifest: () => jfetch('data/manifest.json'),
  curriculum: () => jfetch('data/curriculum.json'),
  chapter: id => jfetch(`data/curriculum/${id}.json`),
  questions: ch => jfetch(`data/questions/questions-${String(ch).replace(/^C/, '').padStart(2, '0')}.json`).then(d => d.questions),
  drugs: () => jfetch('data/drugs.json').then(d => d.records),
  forms: () => jfetch('data/forms.json').then(d => d.records),
  routes: () => jfetch('data/routes.json').then(d => d.records),
  calcs: () => jfetch('data/calculators.json').then(d => d.records),
  abbr: () => jfetch('data/abbreviations/abbr-01-sig.json').then(d => d.records),
  terms: async () => {
    const m = await API.manifest();
    const all = [];
    for (const f of (m.banks.terms.files || [])) all.push(...(await jfetch(/^data\//.test(f) ? f : `data/terms/${f}`)).records);
    return all;
  },
  scenarios: async () => {
    const m = await API.manifest();
    const all = [];
    for (const f of (m.banks.scenarios.files || [])) all.push(...(await jfetch(/^data\//.test(f) ? f : `data/scenarios/${f}`)).records);
    return all;
  },
  esc: () => jfetch('data/escalation-rules.json').then(d => d.records),
  tips: () => jfetch('data/tips.json').then(d => d.records),
  errpat: () => jfetch('data/error-patterns.json').then(d => d.records),
  sources: () => jfetch('data/sources.json').then(d => d.sources),
  prescriptions: async () => {
    const m = await API.manifest();
    const all = [];
    for (const f of ((m.banks.prescriptions || {}).files || [])) { const d = await jfetch(f); all.push(...(d.records || [])); }
    return all;
  },
};

/* ---------------- موتور پیشرفت واقعی (از دادهٔ ذخیره‌شده) ---------------- */
const prog = {
  _shards: {},
  async shard(chId) { return this._shards[chId] ??= await API.chapter(chId); },
  async lessonProgress(chId, lessonId) {
    const sh = await this.shard(chId);
    const l = sh.lessons.find(x => x.id === lessonId);
    if (!l) return { read: 0, total: 0, pctv: 0, done: false };
    const read = store.lessonReadCount(l);
    return { read, total: l.page_ids.length, pctv: pct(read, l.page_ids.length), done: read >= l.page_ids.length };
  },
  async chapterProgress(chId) {
    const sh = await this.shard(chId);
    const total = sh.lessons.reduce((a, l) => a + l.page_ids.length, 0);
    const read = sh.lessons.reduce((a, l) => a + store.lessonReadCount(l), 0);
    return { read, total, pctv: pct(read, total), done: total > 0 && read >= total };
  },
  async overall(cur) {
    let total = 0, read = 0;
    for (const c of cur.chapters) {
      const sh = await this.shard(c.id);
      total += sh.lessons.reduce((a, l) => a + l.page_ids.length, 0);
      read += sh.lessons.reduce((a, l) => a + store.lessonReadCount(l), 0);
    }
    return { read, total, pctv: pct(read, total) };
  },
};

/* قفل‌ها: حالت ترتیبی بر اساس تکمیل واقعی مرحلهٔ قبل */
async function chapterLock(cur, chId) {
  if (settings.get().study.mode === 'free') return { locked: false };
  const idx = cur.chapters.findIndex(c => c.id === chId);
  if (idx <= 0) return { locked: false };
  const prev = cur.chapters[idx - 1];
  const p = await prog.chapterProgress(prev.id);
  return { locked: !p.done, reason: 'این فصل پس از تکمیل فصل قبلی باز می‌شود.', cond: `تکمیل فصل ${faNum(prev.order)}: ${faNum(p.pctv)}٪`, prev };
}
async function lessonLock(cur, chId, lessonId) {
  if (settings.get().study.mode === 'free') return { locked: false };
  const chLock = await chapterLock(cur, chId);
  if (chLock.locked) return chLock;
  const sh = await prog.shard(chId);
  const idx = sh.lessons.findIndex(l => l.id === lessonId);
  if (idx <= 0) return { locked: false };
  const prev = sh.lessons[idx - 1];
  const p = await prog.lessonProgress(chId, prev.id);
  return { locked: !p.done, reason: 'این درس پس از تکمیل درس قبلی باز می‌شود.', cond: `تکمیل درس قبلی: ${faNum(p.pctv)}٪`, prev };
}
async function lessonQuizLock(cur, chId, lessonId) {
  if (settings.get().study.mode === 'free') return { locked: false };
  const chLock = await chapterLock(cur, chId);
  if (chLock.locked) return chLock;
  const sh = await prog.shard(chId);
  const idx = sh.lessons.findIndex(l => l.id === lessonId);
  if (idx <= 0) return { locked: false };
  const prev = sh.lessons[idx - 1];
  return { locked: !store.get().quizDone[prev.id], reason: 'آزمون این درس پس از تکمیل آزمون درس قبلی باز می‌شود.', cond: `تکمیل آزمون درس قبلی: ${prev.title_fa}` };
}


/* ---------------- حلقهٔ پیشرفت ---------------- */
function ring(p, size = 64, stroke = 5, cls = '') {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  const off = c * (1 - Math.min(100, Math.max(0, p)) / 100);
  return h('span', {
    class: 'ringwrap ' + cls,
    html: `<svg class="ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
      <circle class="tr" cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke-width="${stroke}"/>
      <circle class="fg" cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke-width="${stroke}" stroke-linecap="round"
        stroke-dasharray="${c.toFixed(1)}" stroke-dashoffset="${off.toFixed(1)}"/></svg>`
  });
}
function medal(order, p, state, cha) {
  return h('div', { class: `medal ${cha} ` + (state === 'done' ? 'done' : state === 'locked' ? 'locked' : '') },
    h('span', { class: 'core', html: state === 'done' ? IC.check : state === 'locked' ? IC.lock : faNum(order) }),
    ring(p, 64, 4.5));
}

/* ---------------- بلوک بازخورد پاسخ ---------------- */
function fbBlock(good, fb) {
  const d = h('div', { class: 'fb ' + (good ? 'ok' : 'no') }, h('h4', {}, good ? 'درست است' : 'درست نبود'));
  if (fb) {
    if (good && fb.why_correct) d.append(h('p', {}, fb.why_correct));
    if (!good && fb.why_correct) d.append(h('p', {}, 'پاسخ درست: ', fb.why_correct));
    const notes = (fb.wrong_option_notes || []).filter(Boolean);
    if (notes.length) d.append(h('ul', {}, notes.map(n => h('li', {}, n))));
    if (fb.refer_fa) d.append(h('div', { class: 'ref' }, '📎 ' + fb.refer_fa));
  }
  return d;
}

/* ---------------- منوی بازشوی درجا (بدون شیت) ---------------- */
function dropdown(label, items, current, onpick) {
  const lab = h('span', { class: 'small dim', style: 'margin-inline-end:6px' }, label);
  const val = h('b', { style: 'font-size:.8rem' }, (items.find(x => x.k === current) || {}).t || '');
  const btn = h('button', { class: 'sortbtn', 'aria-haspopup': 'menu', 'aria-expanded': 'false' }, lab, val, h('span', { class: 'ddc', html: IC.chev }));
  const menu = h('div', { class: 'ddmenu', role: 'menu' });
  let open = false;
  const close = () => { open = false; menu.classList.remove('show'); btn.setAttribute('aria-expanded', 'false'); };
  items.forEach(it => {
    const b = h('button', { class: it.k === current ? 'on' : '', role: 'menuitem' }, it.t);
    b.onclick = e => { e.stopPropagation(); current = it.k; val.textContent = it.t; menu.querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); close(); onpick(it.k); };
    menu.append(b);
  });
  btn.onclick = e => { e.stopPropagation(); open = !open; menu.classList.toggle('show', open); btn.setAttribute('aria-expanded', String(open)); };
  return { el: h('div', { class: 'dd' }, btn, menu), close };
}

/* ---------------- بینندهٔ نسخه: فقط بزرگ‌نمایی/جابجایی نمایشی؛ بایت‌ها دست‌نخورده ---------------- */
function openRxViewer(rec, opts = {}) {
  const src = rec.asset_file || rec.image_file;
  const img = h('img', { src, alt: rec.title_fa || 'نسخه', draggable: false });
  let sc = 1, tx = 0, ty = 0, drag = null;
  const apply = () => { img.style.transform = `translate(${tx}px, ${ty}px) scale(${sc})`; };
  img.addEventListener('pointerdown', e => { drag = { x: e.clientX - tx, y: e.clientY - ty }; img.setPointerCapture(e.pointerId); });
  img.addEventListener('pointermove', e => { if (!drag) return; tx = e.clientX - drag.x; ty = e.clientY - drag.y; apply(); });
  img.addEventListener('pointerup', () => drag = null);
  img.addEventListener('pointercancel', () => drag = null);
  const zb = (t, fn) => h('button', { class: 'vz', onclick: fn }, t);
  const ov = h('div', { class: 'viewer' },
    h('div', { class: 'vtop' },
      h('button', { class: 'vclose', onclick: () => ov.remove() }, '✕'),
      h('span', { class: 'small grow' }, rec.title_fa || rec.id || 'نسخه'),
      zb('−', () => { sc = Math.max(0.5, sc - 0.25); apply(); }),
      zb('+', () => { sc = Math.min(5, sc + 0.25); apply(); }),
      zb('۱۰٪', () => { sc = 1; tx = 0; ty = 0; apply(); })),
    h('div', { class: 'vbody' }, img),
    h('div', { class: 'vmeta' },
      h('div', {}, rec.specialty_fa ? 'تخصص: ' + rec.specialty_fa : (rec.note_fa || 'نسخهٔ واقعی — نمایش بدون هیچ تغییری در تصویر.')),
      rec.source_url ? h('div', { class: 'num dim' }, 'منبع: ' + rec.source_url) : null,
      rec.source_reading_fa ? h('div', { class: 'mt', style: 'line-height:2' }, 'بازنویسی منبع: ' + rec.source_reading_fa) : null,
      opts.extra || null));
  document.body.append(ov);
  ov.addEventListener('click', ev => { if (ev.target === ov || ev.target.classList.contains('vbody')) ov.remove(); });
}

/* ---------------- skeleton ---------------- */
const skeleton = (rows = 4, hpx = 64) => h('div', {},
  Array.from({ length: rows }, () => h('div', { class: 'skel mb', style: `height:${hpx}px` })));
const spinner = (msg = 'در حال بارگذاری…') => h('div', { class: 'empty' }, msg);
const errBox = e => h('div', { class: 'card' },
  h('b', {}, 'خطا در بارگذاری داده'),
  h('p', { class: 'small' }, String(e && e.message || e)),
  h('p', { class: 'small' }, 'اگر اولین بار است، یک‌بار آنلاین باشید تا فایل‌ها کش شوند.'));

/* ---------------- پوسته: تاپ‌بار + ناوبری پایین (۶ تب) ---------------- */
const app = () => $('#app');
const TABS = [
  { id: 'learn', label: 'آموزش', icon: 'book', re: /^#\/learn/ },
  { id: 'assess', label: 'سنجش', icon: 'quiz', re: /^#\/assess/ },
  { id: 'pharmacy', label: 'داروخانه', icon: 'pharma', re: /^#\/pharmacy/ },
  { id: 'rxread', label: 'نسخه‌خوان', icon: 'rx', re: /^#\/rx/ },
  { id: 'counter', label: 'پیشخوان', icon: 'home', re: /^#\/$|^#\/calc|^#\/terms|^#\/escalation|^#\/errpat|^#\/tips|^#\/search/ },
  { id: 'settings', label: 'تنظیمات', icon: 'gear', re: /^#\/settings/ },
];
function shell(title, body, opts = {}) {
  const hash = location.hash || '#/';
  app().replaceChildren(
    h('div', { class: 'topbar' },
      h('div', { class: 'wrap row' },
        opts.back
          ? h('button', { class: 'backbtn', 'aria-label': 'بازگشت', html: IC.back, onclick: () => { opts.back === true ? history.back() : (location.hash = opts.back); } })
          : h('span', { class: 'branddot', html: '℞' }),
        h('div', { class: 'grow', style: 'min-width:0' },
          h('div', { class: 'tb-title' }, title),
          opts.sub ? h('div', { class: 'tb-sub' }, opts.sub) : null))),
    h('main', { class: 'wrap page' }, body),
    h('nav', { class: 'bnav', 'aria-label': 'ناوبری اصلی' },
      h('div', { class: 'bnav-in' }, TABS.map(t =>
        h('a', { href: '#/' + (t.id === 'counter' ? '' : t.id === 'learn' ? 'learn' : t.id === 'assess' ? 'assess' : t.id === 'pharmacy' ? 'pharmacy' : t.id === 'rxread' ? 'rx' : t.id),
          class: t.re.test(hash) ? 'on' : '', 'aria-current': t.re.test(hash) ? 'page' : null, html: IC[t.icon] }, h('span', {}, t.label)))))
  );
  document.title = title ? `${title} — RX-ACADEMY` : 'RX-ACADEMY';
  window.scrollTo(0, 0);
}

/* ---------------- مارک‌داون کتابچه (امن: بدون اسکریپت خارجی) ---------------- */
function mdToHtml(md) {
  const lines = String(md).split(/\r?\n/);
  let out = [], inList = null, para = [];
  const flushP = () => { if (para.length) { out.push(`<p>${inline(para.join(' '))}</p>`); para = []; } };
  const flushL = () => { if (inList) { out.push(`</${inList}>`); inList = null; } };
  const inline = s => esc(s)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/«([^»]+)»/g, '«$1»')
    .replace(/`([^`]+)`/g, '<code style="background:var(--surface-3);border-radius:6px;padding:0 6px;font-size:.86em">$1</code>');
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (/^###\s/.test(line)) { flushP(); flushL(); out.push(`<h3>${inline(line.replace(/^###\s+/, ''))}</h3>`); }
    else if (/^##\s/.test(line)) { flushP(); flushL(); out.push(`<h2>${inline(line.replace(/^##\s+/, ''))}</h2>`); }
    else if (/^#\s/.test(line)) { flushP(); flushL(); out.push(`<h1>${inline(line.replace(/^#\s+/, ''))}</h1>`); }
    else if (/^>\s?/.test(line)) {
      flushP(); flushL();
      const q = inline(line.replace(/^>\s?/, ''));
      if (out.length && /^<blockquote>/.test(out[out.length - 1]) && !/<\/blockquote>$/.test(out[out.length - 1])) out[out.length - 1] += `<p>${q}</p>`;
      else out.push(`<blockquote><p>${q}</p></blockquote>`);
    }
    else if (/^-\s+/.test(line)) { flushP(); if (inList !== 'ul') { flushL(); out.push('<ul>'); inList = 'ul'; } out.push(`<li>${inline(line.replace(/^-\s+/, ''))}</li>`); }
    else if (/^\d+\.\s+/.test(line)) { flushP(); if (inList !== 'ol') { flushL(); out.push('<ol>'); inList = 'ol'; } out.push(`<li>${inline(line.replace(/^\d+\.\s+/, ''))}</li>`); }
    else if (line.trim() === '') { flushP(); flushL(); }
    else para.push(line.trim());
  }
  flushP(); flushL();
  // بستن بلاک‌کوت‌های باز
  out = out.map(b => /^<blockquote>/.test(b) && !/<\/blockquote>$/.test(b) ? b + '</blockquote>' : b);
  return out.join('\n');
}

/* ============================================================
   تب آموزش — فصل → درس → صفحه (صفحات مستقل، بدون آکاردئون)
   ============================================================ */
async function viewLearn() {
  const body = h('div', {}, skeleton(5, 84));
  shell('آموزش', body);
  try {
    const cur = await API.curriculum();
    const rows = [];
    for (const c of cur.chapters) {
      const p = await prog.chapterProgress(c.id);
      const lock = await chapterLock(cur, c.id);
      const state = lock.locked ? 'locked' : p.done ? 'done' : p.pctv > 0 ? 'doing' : 'new';
      const card = h('div', { class: `card click cha-${c.order}` },
        h('div', { class: 'item-head' },
          h('div', { class: 'item-title' }, c.title_fa),
          state === 'done' ? h('span', { class: 'chip ok' }, 'تکمیل شد')
            : state === 'locked' ? h('span', { class: 'chip lock' }, 'قفل') : null,
          h('span', { class: 'chev', html: IC.chev })),
        c.summary ? h('div', { class: 'item-sub' }, c.summary) : null,
        settings.get().study.showProgress && p.pctv > 0 && !p.done ? h('div', { class: 'progress mt' }, h('i', { style: `width:${p.pctv}%` })) : null);
      if (!lock.locked) card.onclick = () => location.hash = `#/learn/${c.id}`;
      else card.onclick = () => toast(lock.reason + ' ' + lock.cond);
      rows.push(h('div', { class: 'path-item' }, medal(c.order, p.pctv, state, `cha-${c.order}`), card));
    }
    const ov = await prog.overall(cur);
    const head = settings.get().study.showProgress
      ? h('div', { class: 'card flat mb' },
          h('div', { class: 'flex', style: 'justify-content:space-between' },
            h('b', { style: 'font-size:.86rem' }, 'پیشرفت کل آموزش'),
            h('span', { class: 'chip acc num' }, faNum(ov.pctv) + '٪')),
          h('div', { class: 'progress mt' }, h('i', { style: `width:${ov.pctv}%` })))
      : null;
    body.replaceChildren(head ? h('div', {}, head) : h('div', {}), h('div', { class: 'path' }, rows));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewChapter(chId) {
  const body = h('div', {}, skeleton(4, 76));
  shell('فصل', body, { back: '#/learn' });
  try {
    const cur = await API.curriculum();
    const meta = cur.chapters.find(c => c.id === chId);
    if (!meta) { body.replaceChildren(h('div', { class: 'empty' }, 'فصل پیدا نشد.')); return; }
    const lock = await chapterLock(cur, chId);
    if (lock.locked) {
      body.replaceChildren(h('div', { class: 'empty' },
        h('div', { class: 'big', html: IC.lock }),
        'این فصل هنوز قفل است.',
        h('div', { class: 'small mt' }, lock.cond)));
      return;
    }
    const sh = await prog.shard(chId);
    const cp = await prog.chapterProgress(chId);
    const lessonCards = [];
    for (const l of sh.lessons) {
      const lp = await prog.lessonProgress(chId, l.id);
      const ll = await lessonLock(cur, chId, l.id);
      const state = ll.locked ? 'locked' : lp.done ? 'done' : lp.pctv > 0 ? 'doing' : 'new';
      const card = h('div', { class: 'card click' },
        h('div', { class: 'item-head' },
          h('div', { class: 'item-title' }, l.title_fa),
          state === 'locked' ? h('span', { class: 'chip lock', html: IC.lock }) : null,
          h('span', { class: 'chev', html: IC.chev })),
        ll.locked ? h('div', { class: 'item-sub' }, ll.cond) : (l.summary ? h('div', { class: 'item-sub' }, l.summary) : null),
        settings.get().study.showProgress && lp.pctv > 0 && !lp.done ? h('div', { class: 'progress mt' }, h('i', { style: `width:${lp.pctv}%` })) : null);
      if (!ll.locked) card.onclick = () => location.hash = `#/learn/${chId}/lesson/${l.id}`;
      else card.onclick = () => toast(ll.reason);
      lessonCards.push(h('div', { class: 'path-item' },
        medal(l.order, lp.pctv, state, `cha-${meta.order}`), card));
    }
    // ادامه از آخرین صفحهٔ این فصل
    const last = store.get().lastPage;
    let cont = null;
    if (settings.get().study.autoResume && last && last.ch === chId) {
      const l = sh.lessons.find(x => x.id === last.lesson);
      cont = h('button', { class: 'btn soft block mb', onclick: () => location.hash = `#/learn/${chId}/lesson/${last.lesson}?p=${last.page}` },
        h('span', { html: IC.play }), 'ادامه از آخرین نقطهٔ مطالعه' + (l ? ` — ${l.title_fa}` : ''));
    }
    body.replaceChildren(
      h('div', { class: 'crumb' }, h('span', {}, 'آموزش'), '‹', h('b', {}, 'فصل ' + faNum(meta.order))),
      h('div', { class: 'card mb' },
        h('div', { class: 'flex', style: 'gap:14px' },
          medal(meta.order, cp.pctv, cp.done ? 'done' : cp.pctv > 0 ? 'doing' : 'new', `cha-${meta.order}`),
          h('div', { class: 'grow' },
            h('h1', { class: 'page-title', style: 'margin-top:0' }, meta.title_fa),
            meta.summary ? h('p', { class: 'page-sub', style: 'margin:0' }, meta.summary) : null))),
      cont,
      h('div', { class: 'path' }, lessonCards));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewLesson(chId, lessonId, qpage) {
  const body = h('div', {}, skeleton(3, 120));
  shell('درس', body, { back: `#/learn/${chId}` });
  try {
    const cur = await API.curriculum();
    const sh = await prog.shard(chId);
    const meta = cur.chapters.find(c => c.id === chId);
    const lesson = sh.lessons.find(l => l.id === lessonId);
    if (!lesson) { body.replaceChildren(h('div', { class: 'empty' }, 'درس پیدا نشد.')); return; }
    const ll = await lessonLock(cur, chId, lessonId);
    if (ll.locked) {
      body.replaceChildren(h('div', { class: 'empty' },
        h('div', { class: 'big', html: IC.lock }), ll.reason,
        h('div', { class: 'small mt' }, ll.cond)));
      return;
    }
    const pages = sh.pages.filter(p => p.lesson_id === lessonId).sort((a, b) => a.order - b.order);
    let idx = Math.max(0, pages.findIndex(p => p.id === qpage));
    const content = h('div', { class: 'md' });
    const header = h('div', {});
    const footer = h('div', {});

    async function show(i) {
      idx = Math.min(Math.max(0, i), pages.length - 1);
      const pg = pages[idx];
      const md = await (await fetch(pg.path)).text();
      store.markPage(pg.id, { ch: chId, lesson: lessonId, page: pg.id });
      const lp = await prog.lessonProgress(chId, lessonId);
      header.replaceChildren(
        h('div', { class: 'crumb' }, h('span', {}, meta.title_fa), '‹', h('b', {}, lesson.title_fa)),
        h('h1', { class: 'page-title' }, lesson.title_fa),
        settings.get().study.showProgress ? h('div', { class: 'flex mt', style: 'justify-content:space-between' },
          h('span', { class: 'small dim' }, `صفحهٔ ${faNum(idx + 1)} از ${faNum(pages.length)}`),
          h('span', { class: 'small dim num' }, 'پیشرفت درس: ' + faNum(lp.pctv) + '٪')) : null,
        settings.get().study.showProgress ? h('div', { class: 'progress mt' }, h('i', { style: `width:${lp.pctv}%` })) : null);
      content.innerHTML = mdToHtml(md);
      const dots = h('div', { class: 'pdots' }, pages.map((p, k) => h('i', { class: k === idx ? 'on' : '', style: k < idx || k === idx ? '' : '' })));
      const prevB = h('button', { class: 'btn', style: 'flex:1', disabled: idx === 0 || null }, 'قبلی');
      const nextB = h('button', { class: 'btn acc', style: 'flex:1' }, idx === pages.length - 1 ? 'پایان درس' : 'بعدی');
      prevB.onclick = () => idx > 0 && show(idx - 1);
      nextB.onclick = async () => {
        if (idx < pages.length - 1) return show(idx + 1);
        // پایان درس → درس بعد
        const li = sh.lessons.findIndex(l => l.id === lessonId);
        if (li < sh.lessons.length - 1) location.hash = `#/learn/${chId}/lesson/${sh.lessons[li + 1].id}`;
        else location.hash = `#/learn/${chId}`;
      };
      footer.replaceChildren(
        h('div', { class: 'read-footer' }, dots),
        h('div', { class: 'pagenav' }, prevB, nextB));
      window.scrollTo(0, 0);
    }
    body.replaceChildren(header, content, footer);
    await show(idx);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ============================================================
   تب سنجش — آزمون (فصل‌محور) + سناریوهای تمرین
   ============================================================ */
async function viewAssess() {
  const body = h('div', {});
  shell('سنجش', body);
  const mkCard = (hash, icon, title, desc) => h('div', { class: 'card click module-card', onclick: () => location.hash = hash },
    h('div', { class: 'mico', html: IC[icon] }),
    h('div', { class: 'grow' }, h('div', { class: 'item-title' }, title), h('div', { class: 'item-sub' }, desc)),
    h('span', { class: 'chev', html: IC.chev }));
  body.replaceChildren(
    mkCard('#/assess/quiz', 'quiz', 'آزمون', 'سنجش فصل‌به‌فصل با بازخورد و ذخیرهٔ عملکرد'),
    mkCard('#/assess/scenarios', 'rx', 'سناریوهای تمرین', 'تمرین موقعیت‌های واقعی پیشخوان با معیار ارزیابی'));
}

async function viewQuizChapters() {
  const body = h('div', {}, skeleton(5, 84));
  shell('آزمون', body, { back: '#/assess' });
  try {
    const cur = await API.curriculum();
    const rows = [];
    for (const c of cur.chapters) {
      const sh = await prog.shard(c.id);
      const done = sh.lessons.filter(l => store.get().quizDone[l.id]).length;
      const p = pct(done, sh.lessons.length);
      const lock = await chapterLock(cur, c.id);
      const card = h('div', { class: 'card click' },
        h('div', { class: 'item-head' },
          h('div', { class: 'item-title' }, c.title_fa),
          h('span', { class: 'chev', html: IC.chev })));
      card.onclick = () => lock.locked ? toast(lock.reason + ' ' + lock.cond) : location.hash = `#/assess/quiz/${c.id}`;
      rows.push(h('div', { class: 'path-item' }, medal(c.order, p, lock.locked ? 'locked' : p === 100 ? 'done' : p > 0 ? 'doing' : 'new'), card));
    }
    body.replaceChildren(h('div', { class: 'path' }, rows));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewQuizChapter(chId) {
  const body = h('div', {}, skeleton(4, 70));
  shell('آزمون فصل', body, { back: '#/assess/quiz' });
  try {
    const [cur, sh, qs] = await Promise.all([API.curriculum(), prog.shard(chId), API.questions(chId)]);
    const meta = cur.chapters.find(c => c.id === chId);
    const doneN = sh.lessons.filter(l => store.get().quizDone[l.id]).length;
    const p = pct(doneN, sh.lessons.length);
    const rows = [];
    for (const l of sh.lessons) {
      const ll = await lessonQuizLock(cur, chId, l.id);
      const pool = qs.filter(q => q.lesson_id === l.id);
      const card = h('div', { class: 'card click' },
        h('div', { class: 'item-head' },
          h('div', { class: 'item-title' }, l.title_fa),
          h('span', { class: 'chev', html: IC.chev })));
      card.onclick = () => ll.locked ? toast(ll.reason + ' ' + ll.cond) : startLessonQuiz(chId, l, pool);
      rows.push(h('div', { class: 'path-item' }, medal(l.order, store.get().quizDone[l.id] ? 100 : 0, ll.locked ? 'locked' : store.get().quizDone[l.id] ? 'done' : 'new'), card));
    }
    body.replaceChildren(
      h('div', { class: 'card mb' },
        h('div', { class: 'flex', style: 'gap:14px;align-items:center' },
          medal(meta.order, p, p === 100 ? 'done' : p > 0 ? 'doing' : 'new'),
          h('div', { class: 'grow' }, h('h1', { class: 'page-title', style: 'margin:0' }, meta.title_fa)))),
      h('div', { class: 'path' }, rows));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------- جلسهٔ آزمون درس: ثبت آنی پاسخ، «قبلی» فقط مشاهده، بدون خروج ---------- */
async function startLessonQuiz(chId, lesson, pool) {
  if (!pool.length) { toast('برای این درس هنوز سؤالی ثبت نشده است.'); return; }
  const items = settings.get().quiz.random ? shuffle(pool) : [...pool].sort((a, b) => String(a.id).localeCompare(String(b.id)));
  const st = { i: 0, correct: 0, ans: {} };
  const cur = await API.curriculum();
  const sh = await prog.shard(chId);
  const li = sh.lessons.findIndex(l => l.id === lesson.id);
  renderQ(chId, lesson, items, st, cur, sh, li, pool);
}

function renderQ(chId, lesson, items, st, cur, sh, li, basePool) {
  const box = h('div', { class: 'qcard' });
  const wrap = h('div', { style: 'max-width:44rem;margin:0 auto' }, box);
  shell('آزمون درس', wrap, { back: `#/assess/quiz/${chId}` });
  const show = i => { st.i = i; renderOne(items, i, st, show, finish).then(el => { box.replaceChildren(el); window.scrollTo(0, 0); }); };
  const finish = () => {
    const total = items.length, correct = st.correct, p = pct(correct, total);
    store.recordQuiz(chId, total, correct);
    const d = store.get(); if (!d.quizDone[lesson.id]) { d.quizDone[lesson.id] = 1; store.save(); }
    const nextL = sh.lessons[li + 1];
    box.replaceChildren(
      h('div', { style: 'text-align:center' },
        h('div', { style: 'display:flex;justify-content:center' }, ring(p, 132, 9)),
        h('h1', { class: 'page-title' }, `نتیجه: ${faNum(correct)} از ${faNum(total)} (${faNum(p)}٪)`),
        h('p', { class: 'small dim' }, p >= 80 ? 'عالی — تسلط این درس تأیید شد.' : p >= 50 ? 'خوب بود؛ با مرور کتابچه به تسلط کامل برسید.' : 'پیشنهاد می‌شود صفحات این درس را دوباره مرور کنید.'),
        h('div', { class: 'grid2 mt' },
          h('button', { class: 'btn acc', onclick: () => startLessonQuiz(chId, lesson, basePool) }, 'تلاش دوباره'),
          h('button', { class: 'btn', onclick: () => location.hash = `#/assess/quiz/${chId}` }, 'فهرست درس‌ها')),
        nextL ? h('button', { class: 'btn soft block mt', onclick: async () => {
          const ll = await lessonQuizLock(cur, chId, nextL.id);
          if (ll.locked) { toast(ll.reason); return; }
          const qs = await API.questions(chId);
          startLessonQuiz(chId, nextL, qs.filter(q => q.lesson_id === nextL.id));
        } }, 'آزمون درس بعد') : null));
    window.scrollTo(0, 0);
  };
  show(0);
}

async function renderOne(items, i, st, show, finish) {
  const q = items[i];
  const ans = st.ans[i];
  const frag = h('div', {});
  const head = h('div', { class: 'flex mb', style: 'justify-content:space-between;align-items:center' },
    h('span', { class: 'chip acc num' }, `سؤال ${faNum(i + 1)} از ${faNum(items.length)}`),
    h('span', { class: 'chip' }, ({ single_choice: 'تک‌گزینه‌ای', multi_select: 'چندگزینه‌ای', calculation: 'محاسبه', flashcard: 'فلش‌کارت', rx_read: 'نسخه‌خوانی' })[q.practice_type] || q.practice_type));
  frag.append(head, h('div', { class: 'progress mb' }, h('i', { style: `width:${pct(i, items.length)}%` })));
  const zone = h('div', {});
  const navBtns = h('div', { class: 'flex mt', style: 'gap:8px' },
    i > 0 ? h('button', { class: 'btn soft', onclick: () => show(i - 1) }, 'قبلی (مشاهده)') : null,
    h('button', { class: 'btn acc grow' }, i === items.length - 1 ? 'پایان و نتیجه' : 'سؤال بعد'));
  const nextBtn = navBtns.lastElementChild;
  nextBtn.disabled = !ans;
  nextBtn.onclick = () => { if (i === items.length - 1) finish(); else show(i + 1); };
  const lock = (good) => {
    st.ans[i] = { good }; if (good) st.correct++;
    nextBtn.disabled = false;
  };
  const fb = (good) => zone.append(fbBlock(good, q.feedback_fa));

  if (q.practice_type === 'rx_read' || q.practice_type === 'flashcard') {
    if (q.prescription_id) {
      const recs = await API.prescriptions();
      const rec = recs.find(r => r.id === q.prescription_id);
      if (rec) frag.append(h('div', { class: 'rxthumb mb' }, h('img', { src: rec.asset_file || rec.image_file, alt: rec.title_fa || 'نسخه', onclick: () => openRxViewer(rec) })));
    }
    frag.append(h('p', { class: 'qstem' }, q.stem_fa || q.front_fa));
    if (ans) {
      frag.append(h('div', { class: 'reveal' }, h('b', { class: 'small' }, 'پاسخ منبع:'), h('p', { class: 'small', style: 'line-height:2.1' }, q.back_fa)), zone);
      fb(ans.good);
    } else {
      const rev = h('div', {});
      const showBtn = h('button', { class: 'btn soft block mt' }, q.practice_type === 'rx_read' ? 'نمایش پاسخ منبع' : 'نمایش پاسخ');
      showBtn.onclick = () => { rev.replaceChildren(h('div', { class: 'reveal' }, h('b', { class: 'small' }, q.practice_type === 'rx_read' ? 'بازنویسی منبع:' : 'پاسخ:'), h('p', { class: 'small', style: 'line-height:2.1' }, q.back_fa))); showBtn.remove(); };
      frag.append(rev, showBtn);
      const g1 = h('button', { class: 'btn acc grow' }, 'خواندم / بلد بودم');
      const g0 = h('button', { class: 'btn grow' }, 'نتوانستم خواند');
      g1.onclick = () => { lock(true); fb(true); g0.remove(); g1.remove(); };
      g0.onclick = () => { lock(false); fb(false); g0.remove(); g1.remove(); };
      frag.append(h('div', { class: 'flex mt', style: 'gap:8px' }, g1, g0));
    }
    frag.append(zone, navBtns);
    return frag;
  }

  if (q.practice_type === 'calculation') {
    const inp = h('input', { class: 'inp grow num', inputmode: 'decimal', placeholder: 'پاسخ عددی' });
    const chk = h('button', { class: 'btn acc' }, 'بررسی');
    chk.onclick = () => {
      if (st.ans[i]) return;
      const val = norm(inp.value);
      const good = (q.accepted_answers || []).some(a => norm(String(a)) === val);
      st.ans[i] = { good, val }; if (good) st.correct++;
      nextBtn.disabled = false;
      fb(good);
      inp.disabled = true; chk.remove();
    };
    frag.append(h('p', { class: 'qstem' }, q.stem_fa), h('div', { class: 'flex', style: 'gap:8px' }, inp, chk));
    if (ans) { inp.disabled = true; inp.value = ans.val || ''; chk.remove(); fb(ans.good); }
    frag.append(zone, navBtns);
    return frag;
  }

  if (q.practice_type === 'multi_select') {
    frag.append(h('p', { class: 'qstem' }, q.stem_fa));
    const picks = new Set();
    const els = q.options_fa.map((o, k) => {
      const el = h('button', { class: 'opt' }, h('span', { class: 'mk' }, faNum(k + 1)), h('span', { class: 'grow' }, o));
      el.onclick = () => { if (st.ans[i]) return; picks.has(k) ? (picks.delete(k), el.classList.remove('sel')) : (picks.add(k), el.classList.add('sel')); };
      return el;
    });
    frag.append(...els);
    const chk = h('button', { class: 'btn acc block mt' }, 'بررسی پاسخ');
    chk.onclick = () => {
      if (ans) return;
      const good = q.correct_indices.length === picks.size && q.correct_indices.every(k => picks.has(k));
      st.ans[i] = { good, picks: [...picks] }; if (good) st.correct++; nextBtn.disabled = false;
      els.forEach((e2, k) => { e2.classList.add('dis'); if (q.correct_indices.includes(k)) e2.classList.add('good'); else if (picks.has(k)) e2.classList.add('bad'); });
      fb(good); chk.remove();
    };
    if (ans) { els.forEach((e2, k) => { e2.classList.add('dis'); if (q.correct_indices.includes(k)) e2.classList.add('good'); else if (ans.picks?.includes(k)) e2.classList.add('bad'); }); chk.remove(); fb(ans.good); }
    frag.append(chk, zone, navBtns);
    return frag;
  }

  /* تک‌گزینه‌ای: ثبت آنی با لمس گزینه */
  const ci = (q.correct_index ?? q.correct_answer);
  frag.append(h('p', { class: 'qstem' }, q.stem_fa));
  const els = q.options_fa.map((o, k) => {
    const el = h('button', { class: 'opt' }, h('span', { class: 'mk' }, faNum(k + 1)), h('span', { class: 'grow' }, o));
    el.onclick = () => {
      if (st.ans[i]) return;
      const good = k === ci;
      st.ans[i] = { good, picked: k }; if (good) st.correct++; nextBtn.disabled = false;
      els.forEach((e2, j) => { e2.classList.add('dis'); if (j === ci) e2.classList.add('good'); else if (j === k) e2.classList.add('bad'); });
      fb(good);
    };
    return el;
  });
  frag.append(...els);
  if (ans) { els.forEach((e2, k) => { e2.classList.add('dis'); if (k === ci) e2.classList.add('good'); else if (ans.picked === k) e2.classList.add('bad'); }); fb(ans.good); }
  frag.append(zone, navBtns);
  return frag;
}

/* ---------- سناریوهای تمرین ---------- */
async function viewScenarios() {
  const body = h('div', {}, skeleton(4, 92));
  shell('سناریوهای تمرین', body, { back: '#/assess' });
  try {
    const [scns, cur] = await Promise.all([API.scenarios(), API.curriculum()]);
    const chName = id => cur.chapters.find(c => c.id === id)?.title_fa || '';
    const done = store.get().scnDone;
    const cards = scns.map(s => {
      const lvl = h('span', { class: 'lvl', title: 'سطح ' + faNum(s.level) },
        [1, 2, 3].map(k => h('i', { class: k <= s.level ? 'f' : '' })));
      const c = h('div', { class: 'card click' },
        h('div', { class: 'item-head' },
          h('div', { class: 'item-title' }, s.title),
          done[s.id] ? h('span', { class: 'chip ok' }, 'انجام شد') : lvl,
          h('span', { class: 'chev', html: IC.chev })),
        h('div', { class: 'item-sub' }, s.setup),
        s.ch ? h('div', { class: 'small dim mt' }, 'زمینهٔ فصل: ' + chName(s.ch)) : null);
      c.onclick = () => location.hash = `#/assess/scenarios/${encodeURIComponent(s.id)}`;
      return c;
    });
    body.replaceChildren(h('div', {}, cards));
  } catch (e) { body.replaceChildren(errBox(e)); }
}
async function viewScenario(idRaw) {
  const body = h('div', {}, skeleton(2, 140));
  shell('سناریو', body, { back: '#/assess/scenarios' });
  try {
    const id = decodeURIComponent(idRaw);
    const scns = await API.scenarios();
    const s = scns.find(x => x.id === id);
    if (!s) { body.replaceChildren(h('div', { class: 'empty' }, 'سناریو پیدا نشد.')); return; }
    const done = !!store.get().scnDone[id];
    const doneBtn = h('button', { class: 'btn block mt ' + (done ? 'soft' : 'acc') }, done ? 'انجام شده — برداشتن نشان' : 'سناریو را انجام دادم');
    doneBtn.onclick = () => {
      const now = !store.get().scnDone[id];
      store.setScn(id, now);
      doneBtn.className = 'btn block mt ' + (now ? 'soft' : 'acc');
      doneBtn.textContent = now ? 'انجام شده — برداشتن نشان' : 'سناریو را انجام دادم';
    };
    body.replaceChildren(
      h('div', { class: 'card' },
        h('div', { class: 'flex', style: 'justify-content:space-between' },
          h('h1', { class: 'page-title', style: 'margin:0' }, s.title),
          h('span', { class: 'chip acc' }, 'سطح ' + faNum(s.level))),
        h('div', { class: 'sec-title', style: 'margin-top:14px' }, 'صحنه'),
        h('p', { class: 'small', style: 'line-height:2.1' }, s.setup),
        h('div', { class: 'sec-title' }, 'وظیفهٔ شما'),
        h('p', { class: 'small', style: 'line-height:2.1' }, s.task),
        h('div', { class: 'sec-title' }, 'معیار ارزیابی'),
        h('p', { class: 'small', style: 'line-height:2.1' }, s.check),
        doneBtn));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------- toast سبک ---------- */
let toastEl = null;
function toast(msg) {
  toastEl?.remove();
  toastEl = h('div', {
    role: 'status',
    style: 'position:fixed;bottom:calc(var(--nav-h) + 20px + env(safe-area-inset-bottom));right:16px;left:16px;z-index:120;margin-inline:auto;max-width:420px;background:var(--surface);border:1px solid var(--border-2);box-shadow:var(--shadow-2);border-radius:12px;padding:11px 14px;font-size:.82rem;text-align:center;animation:rise 160ms ease-out'
  }, msg);
  document.body.append(toastEl);
  setTimeout(() => toastEl?.remove(), 2600);
}

/* ============================================================
   تب داروخانه — فهرست داروها + فرم‌های دارویی + مسیرهای تجویز
   ============================================================ */
async function viewPharmacy() {
  const body = h('div', {});
  shell('داروخانه', body);
  const mkCard = (hash, icon, title, desc) => h('div', { class: 'card click module-card', onclick: () => location.hash = hash },
    h('div', { class: 'mico', html: IC[icon] }),
    h('div', { class: 'grow' }, h('div', { class: 'item-title' }, title), h('div', { class: 'item-sub' }, desc)),
    h('span', { class: 'chev', html: IC.chev }));
  body.replaceChildren(
    mkCard('#/pharmacy/drugs', 'pharma', 'داروها', 'جست‌وجو، مرتب‌سازی و گروه‌بندی مرجع دارویی'),
    mkCard('#/pharmacy/forms', 'doc', 'فرم‌های دارویی', 'فهرست اشکال دارویی بر اساس طبقه'),
    mkCard('#/pharmacy/routes', 'rx', 'مسیرهای تجویز', 'راه‌های مصرف بر اساس طبقه'));
}

/* ---------- فهرست داروها: جست‌وجو + شیت گروه‌بندی/مرتب‌سازی + مجازی‌سازی ---------- */
async function viewDrugs() {
  shell('داروها', h('div', {}, spinner()), { back: '#/pharmacy' });
  const recs = await API.drugs();
  const SORTS = [
    { k: 'name_fa', t: 'نام فارسی (الفبا)' },
    { k: 'name_en', t: 'نام انگلیسی (الفبا)' },
    { k: 'atc_code', t: 'کد رسمی (ATC)' },
    { k: 'atc_chapter_name', t: 'فصل طبقه‌بندی' },
    { k: 'high_alert', t: 'پرخطرها در صدر' },
  ];
  const state = { q: '', sort: 'name_fa' };
  const dd = dropdown('مرتب‌سازی بر اساس', SORTS, state.sort, k => { state.sort = k; apply(); });
  const vp = h('div', { class: 'vlist' });
  let filtered = [];
  const hay = r => norm([r.name_fa, r.name_en, r.atc_code, r.drug_class_fa, (r.group_path || []).join(' '), r.atc_chapter_name].join(' '));
  function apply() {
    let list = recs.filter(r => !state.q || state.q.split(/\s+/).every(w => hay(r).includes(w)));
    list.sort((a, b) => {
      if (state.sort === 'high_alert') return (b.high_alert ? 1 : 0) - (a.high_alert ? 1 : 0) || String(a.name_fa || '').localeCompare(String(b.name_fa || ''), 'fa');
      return String(a[state.sort] || '').localeCompare(String(b[state.sort] || ''), state.sort === 'name_en' ? 'en' : 'fa');
    });
    filtered = list;
    renderVirtual();
  }
  function renderVirtual() {
    const IH = 58, BUF = 8;
    const inner = h('div', { style: `position:relative;height:${filtered.length * IH}px` });
    vp.replaceChildren(inner);
    let start = -1, end = -1;
    const onScroll = () => {
      const s = Math.max(0, Math.floor(vp.scrollTop / IH) - BUF);
      const e = Math.min(filtered.length, Math.ceil((vp.scrollTop + vp.clientHeight) / IH) + BUF);
      if (s === start && e === end) return;
      start = s; end = e;
      const frag = document.createDocumentFragment();
      for (let i = s; i < e; i++) {
        const r = filtered[i];
        frag.append(h('a', { class: 'vrow', href: `#/pharmacy/drug/${encodeURIComponent(r.id)}`, style: `top:${i * IH}px` },
          h('span', { class: 'grow', style: 'min-width:0' },
            h('b', {}, r.name_fa || '—', r.high_alert ? ' ' : ''),
            r.high_alert ? h('span', { class: 'chip err', style: 'margin-inline-start:6px;padding:1px 7px;font-size:.62rem' }, 'پرخطر') : null,
            h('div', { class: 'sub' }, [r.name_en, r.atc_code || 'بدون کد', r.drug_class_fa].filter(Boolean).join(' · '))),
          h('span', { class: 'chev', html: IC.chev })));
      }
      inner.replaceChildren(frag);
    };
    vp.onscroll = onScroll;
    onScroll();
  }
  try {
    const search = h('div', { class: 'searchbar mb' }, ic('search'), h('input', { class: 'inp', type: 'search', id: 'dq', placeholder: 'جست‌وجو: نام، کد، کلاس، مسیر گروهی…', 'aria-label': 'جست‌وجوی دارو' }));
    const body2 = h('div', {}, h('div', { class: 'toolbar' }, dd.el), search, vp);
    shell('داروها', body2, { back: '#/pharmacy' });
    $('#dq').oninput = e => { state.q = norm(e.target.value); vp.scrollTop = 0; apply(); };
    apply();
  } catch (e) { app().replaceChildren(errBox(e)); }
}


async function viewDrug(idRaw) {
  const body = h('div', {}, skeleton(2, 200));
  shell('دارو', body, { back: '#/pharmacy/drugs' });
  try {
    const id = decodeURIComponent(idRaw);
    const recs = await API.drugs();
    const d = recs.find(x => x.id === id);
    if (!d) { body.replaceChildren(h('div', { class: 'empty' }, 'دارو پیدا نشد.')); return; }
    store.setLastDrug(d.id);
    const row = (k, v) => v === null || v === undefined || v === '' ? null
      : h('div', { class: 'rowline' }, h('span', { class: 'small' }, k), h('b', { style: 'font-size:.88rem' }, Array.isArray(v) ? v.join(' ← ') : String(v)));
    const flags = [];
    if (d.high_alert) flags.push(h('span', { class: 'chip warn' }, 'پرخطر (نیازمند کنترل مضاعف)'));
    if (d.lasa_group) flags.push(h('span', { class: 'chip err' }, 'نام/ظاهر مشابه — گروه ' + d.lasa_group));
    body.replaceChildren(
      h('div', { class: 'card' },
        h('h1', { class: 'page-title', style: 'margin-top:0' }, d.name_fa),
        h('div', { class: 'page-sub num', style: 'margin:0' }, d.name_en),
        flags.length ? h('div', { class: 'chips mt' }, flags) : null),
      h('div', { class: 'card pad0 mt' },
        row('کد رسمی', d.atc_code),
        row('فصل طبقه‌بندی', d.atc_chapter_name),
        row('مسیر گروهی', d.group_path),
        row('کلاس دارویی', d.drug_class_fa),
        row('فرم‌ها', d.forms),
        row('مسیرهای مصرف', d.routes),
        row('ممنوعیت‌ها', d.contraindicated_in),
        row('نگهداری', d.storage_note),
        row('منبع', (d.source_ids || []).join('، ') || d.fa_source)),
      h('p', { class: 'small mt' }, 'فیلدهای خالی یعنی دادهٔ تأییدشده در دسترس نیست (صداقت بر کاملیت). این کارت برای بازشناسی و تطبیق است، نه مشاورهٔ درمانی.'),
      h('p', { class: 'small dim' }, DISCLAIMER));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------- فرم‌ها و مسیرها (فقط فیلدهای واقعی موجود) ---------- */
async function viewForms() {
  const body = h('div', {}, skeleton(3, 90));
  shell('فرم‌های دارویی', body, { back: '#/pharmacy' });
  try {
    const recs = await API.forms();
    const cats = [...new Set(recs.map(r => r.form_class).filter(Boolean))].sort();
    const secs = [];
    for (const cat of (cats.length ? cats : [''])) {
      const list = recs.filter(r => (r.form_class || '') === cat);
      secs.push(cat ? h('div', { class: 'sec-title' }, cat) : null,
        ...list.map(r => h('div', { class: 'card click', onclick: () => location.hash = `#/pharmacy/forms/${encodeURIComponent(r.id)}` },
          h('div', { class: 'item-head' },
            h('div', { class: 'item-title' }, r.name_fa),
            h('span', { class: 'chip num' }, r.name_en),
            h('span', { class: 'chev', html: IC.chev })))));
    }
    body.replaceChildren(...secs.filter(Boolean));
  } catch (e) { body.replaceChildren(errBox(e)); }
}
async function viewForm(idRaw) {
  const body = h('div', {}, skeleton(2, 160));
  shell('فرم دارویی', body, { back: '#/pharmacy/forms' });
  try {
    const id = decodeURIComponent(idRaw);
    const recs = await API.forms();
    const r = recs.find(x => x.id === id);
    if (!r) { body.replaceChildren(h('div', { class: 'empty' }, 'فرم پیدا نشد.')); return; }
    const row = (k, v) => v === null || v === undefined || v === '' ? null
      : h('div', { class: 'rowline' }, h('span', { class: 'small' }, k), h('b', { style: 'font-size:.88rem' }, Array.isArray(v) ? v.join('، ') : String(v)));
    body.replaceChildren(h('div', { class: 'card' },
      h('h1', { class: 'page-title', style: 'margin-top:0' }, r.name_fa),
      h('div', { class: 'chips' }, [r.name_en, r.form_class].filter(Boolean).map(x => h('span', { class: 'chip acc' }, x))),
      h('div', { class: 'pad0 mt' },
        row('نام انگلیسی', r.name_en),
        row('طبقهٔ فرم', r.form_class),
        row('منبع', (r.source_ids || []).join('، ') || r.fa_source))));
  } catch (e) { body.replaceChildren(errBox(e)); }
}
async function viewRoutes() {
  const body = h('div', {}, skeleton(3, 90));
  shell('مسیرهای تجویز', body, { back: '#/pharmacy' });
  try {
    const recs = await API.routes();
    const cats = [...new Set(recs.map(r => r.route_class).filter(Boolean))].sort();
    const secs = [];
    for (const cat of (cats.length ? cats : [''])) {
      const list = recs.filter(r => (r.route_class || '') === cat);
      secs.push(cat ? h('div', { class: 'sec-title' }, cat) : null,
        ...list.map(r => h('div', { class: 'card click', onclick: () => location.hash = `#/pharmacy/routes/${encodeURIComponent(r.id)}` },
          h('div', { class: 'item-head' },
            h('div', { class: 'item-title' }, r.name_fa),
            h('span', { class: 'chip num' }, r.name_en),
            h('span', { class: 'chev', html: IC.chev })))));
    }
    body.replaceChildren(...secs.filter(Boolean));
  } catch (e) { body.replaceChildren(errBox(e)); }
}
async function viewRoute(idRaw) {
  const body = h('div', {}, skeleton(2, 160));
  shell('مسیر تجویز', body, { back: '#/pharmacy/routes' });
  try {
    const id = decodeURIComponent(idRaw);
    const recs = await API.routes();
    const r = recs.find(x => x.id === id);
    if (!r) { body.replaceChildren(h('div', { class: 'empty' }, 'مسیر پیدا نشد.')); return; }
    const row = (k, v) => v === null || v === undefined || v === '' ? null
      : h('div', { class: 'rowline' }, h('span', { class: 'small' }, k), h('b', { style: 'font-size:.88rem' }, Array.isArray(v) ? v.join('، ') : String(v)));
    body.replaceChildren(h('div', { class: 'card' },
      h('h1', { class: 'page-title', style: 'margin-top:0' }, r.name_fa),
      h('div', { class: 'chips' }, [r.name_en, r.route_class].filter(Boolean).map(x => h('span', { class: 'chip acc' }, x))),
      h('div', { class: 'pad0 mt' },
        row('نام انگلیسی', r.name_en),
        row('طبقهٔ مسیر', r.route_class),
        row('منبع', (r.source_ids || []).join('، ') || r.fa_source))));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ============================================================
   تب نسخه‌خوان — گنجینهٔ نسخه + اختصارات نسخه
   ============================================================ */
async function viewRx() {
  const body = h('div', {});
  shell('نسخه‌خوان', body);
  const mkCard = (hash, icon, title, desc) => h('div', { class: 'card click module-card', onclick: () => location.hash = hash },
    h('div', { class: 'mico', html: IC[icon] }),
    h('div', { class: 'grow' }, h('div', { class: 'item-title' }, title), h('div', { class: 'item-sub' }, desc)),
    h('span', { class: 'chev', html: IC.chev }));
  body.replaceChildren(
    mkCard('#/rx/prescriptions', 'doc', 'نسخه', 'کتابخانهٔ نسخه‌های واقعی با بینندهٔ بزرگ‌نمایی'),
    mkCard('#/rx/abbr', 'terms', 'علائم اختصاری', 'علائم دستوری و نکات خوانش'));
}

/* گنجینهٔ نسخه — موتور کامل، صفر تصویر ساختگی (خط قرمز ۱) */
async function viewPrescriptions() {
  const body = h('div', {}, skeleton(3, 120));
  shell('نسخه‌ها', body, { back: '#/rx' });
  try {
    const bank = await API.prescriptions();
    const local = JSON.parse(localStorage.getItem('rx-academy-local-rx') || '[]').map(r => ({ ...r, _local: true }));
    const all = [...bank, ...local];
    const GROUPS = [
      { k: '', t: 'همهٔ منابع' },
      { k: 'src-tg-noskhekhanidorehami', t: 'کانال دورهمی (تلگرام)' },
      { k: 'src-iehe-ir', t: 'وب‌سایت iehe.ir' },
      { k: 'local', t: 'واردشدهٔ محلی' },
    ];
    const SORTS = [
      { k: 'acq', t: 'تاریخ دریافت' },
      { k: 'src', t: 'منبع' },
      { k: 'spec', t: 'تخصص' },
      { k: 'lesson', t: 'درس مرتبط' },
    ];
    const state = { group: '', sort: 'acq' };
    const grid = h('div', { class: 'rxgrid' });
    const ddG = dropdown('گروه‌بندی', GROUPS, state.group, k => { state.group = k; draw(); });
    const ddS = dropdown('مرتب‌سازی بر اساس', SORTS, state.sort, k => { state.sort = k; draw(); });
    function list() {
      let L = all.filter(r => !state.group || (state.group === 'local' ? !!r._local : (r.source_ids || []).includes(state.group)));
      const key = r => state.sort === 'acq' ? (r.acquired_at || (r._imported_at || '').slice(0, 10) || '')
        : state.sort === 'src' ? ((r.source_ids || ['local'])[0])
        : state.sort === 'spec' ? (r.specialty_fa || '—') : (r.lesson_id || '—');
      return L.sort((a, b) => String(key(b)).localeCompare(String(key(a)), 'fa'));
    }
    function draw() {
      const L = list();
      grid.replaceChildren(...L.map(r => {
        const c = h('div', { class: 'card pad0 rxcard' },
          (r.asset_file || r.image_file) ? h('img', { src: r.asset_file || r.image_file, alt: r.title_fa || '', loading: 'lazy' }) : h('div', { class: 'rxph', html: IC.rx }),
          h('div', { style: 'padding:10px' },
            h('b', { style: 'font-size:.8rem;display:block;line-height:1.8' }, r.title_fa || r.id || 'نسخه'),
            h('div', { class: 'small dim' }, [r.specialty_fa, r.lesson_id].filter(Boolean).join(' · '))));
        c.onclick = () => openRxViewer(r, {
          extra: r._local ? h('button', { class: 'btn danger mt', onclick: () => confirmSheet('این نسخهٔ واردشده حذف شود؟', () => {
            const l = JSON.parse(localStorage.getItem('rx-academy-local-rx') || '[]');
            const idx = l.findIndex(x => x.id === r.id || x.title_fa === r.title_fa);
            if (idx >= 0) { l.splice(idx, 1); localStorage.setItem('rx-academy-local-rx', JSON.stringify(l)); }
            document.querySelectorAll('.viewer').forEach(v => v.remove());
            viewPrescriptions();
          }) }, 'حذف این نسخهٔ واردشده') : null,
        });
        return c;
      }));
    }
    /* واردسازی نسخهٔ مستند (فقط همین دستگاه) */
    const file = h('input', { type: 'file', accept: '.json,application/json', style: 'display:none' });
    file.onchange = async () => {
      try {
        const txt = await file.files[0].text();
        const j = JSON.parse(txt);
        const arr = Array.isArray(j) ? j : [j];
        const l = JSON.parse(localStorage.getItem('rx-academy-local-rx') || '[]');
        l.push(...arr.map(r => ({ ...r, _imported_at: new Date().toISOString() })));
        localStorage.setItem('rx-academy-local-rx', JSON.stringify(l));
        viewPrescriptions();
      } catch (e2) { toast('فایل JSON معتبر نبود.'); }
    };
    draw();
    body.replaceChildren(
      h('div', { class: 'toolbar mb' }, ddG.el, ddS.el),
      h('div', { class: 'flex mb', style: 'justify-content:flex-end' },
        h('button', { class: 'btn soft', onclick: () => file.click() }, 'واردسازی نسخهٔ مستند')), file,
      grid,
      !all.length ? h('div', { class: 'empty mt' }, h('div', { class: 'big', html: IC.doc }), 'هنوز نسخه‌ای در کتابخانه نیست.') : null);
  } catch (e) { body.replaceChildren(errBox(e)); }
}


/* اختصارات نسخه — گروه‌بندی فقط با دادهٔ واقعی موجود (حرف اول نماد) */
async function viewAbbr() {
  const body = h('div', {}, skeleton(4, 70));
  shell('اختصارات نسخه', body, { back: '#/rx' });
  try {
    const recs = await API.abbr();
    const first = s => { const c = String(s || '').trim().charAt(0).toUpperCase(); return c || '#'; };
    const letters = [...new Set(recs.map(r => first(r.symbol)))].sort();
    const secs = [];
    const hasRisk = recs.some(r => r.risk);
    for (const L of letters) {
      const list = recs.filter(r => first(r.symbol) === L);
      secs.push(h('div', { class: 'sec-title' }, L),
        ...list.map(r => h('div', { class: 'card' },
          h('div', { class: 'flex', style: 'justify-content:space-between;gap:8px' },
            h('b', { class: 'num', style: 'font-size:1rem' }, r.symbol),
            r.risk ? h('span', { class: 'chip err' }, 'خطر: ' + r.risk) : null),
          h('div', { class: 'small mt' }, r.fa),
          r.en ? h('div', { class: 'small dim num mt' }, r.en) : null,
          r.note ? h('div', { class: 'small mt', style: 'color:var(--warn)' }, '⚠ ' + r.note) : null)));
    }
    body.replaceChildren(
      h('p', { class: 'small dim mb' }, hasRisk
        ? 'برچسب خطر بر اساس فیلد «خطر» موجود در داده‌ها نمایش داده می‌شود.'
        : 'برچسب رسمی خطاخیزی این اختصارات هنوز از منبع رسمی دریافت نشده است (مستند: FAB-09)؛ در تردید، ارجاع دهید.'),
      ...secs);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ============================================================
   تب پیشخوان — ماشین‌حساب · واژگان · قواعد ارجاع · الگوهای خطا · پیشخوان‌داری
   ============================================================ */
async function viewCounter() {
  const body = h('div', {});
  shell('پیشخوان', body);
  let resume = null;
  const last = store.get().lastPage;
  if (settings.get().study.autoResume && last) {
    try {
      const cur = await API.curriculum();
      const meta = cur.chapters.find(c => c.id === last.ch);
      if (meta) resume = h('div', { class: 'card acc-soft click mb', onclick: () => location.hash = `#/learn/${last.ch}/lesson/${last.lesson}?p=${last.page}` },
        h('div', { class: 'item-head' },
          h('div', { class: 'grow' }, h('div', { class: 'item-title' }, 'ادامهٔ مطالعه'),
            h('div', { class: 'item-sub' }, meta.title_fa)),
          h('span', { class: 'chev', html: IC.chev })));
    } catch (e) {}
  }
  const mkCard = (hash, icon, title, desc) => h('div', { class: 'card click module-card', onclick: () => location.hash = hash },
    h('div', { class: 'mico', html: IC[icon] }),
    h('div', { class: 'grow' }, h('div', { class: 'item-title' }, title), h('div', { class: 'item-sub' }, desc)),
    h('span', { class: 'chev', html: IC.chev }));
  body.replaceChildren(
    resume,
    mkCard('#/calc', 'calc', 'ماشین‌حساب داروخانه', 'محاسبه‌های روزمرهٔ پیشخوان'),
    mkCard('#/terms', 'terms', 'واژگان', 'اصطلاح‌های تخصصی نسخه و داروخانه'),
    mkCard('#/escalation', 'esc', 'قواعد ارجاع', 'چه چیزی را باید به داروساز ارجاع داد'),
    mkCard('#/errpat', 'err', 'الگوهای خطا', 'خطاهای رایج نسخه‌خوانی و راه پیشگیری'),
    mkCard('#/tips', 'tips', 'پیشخوان‌داری', 'نکته‌های کوتاه کار در پیشخوان'));
}

/* ماشین‌حساب‌ها — منطق محاسبهٔ نسخهٔ قبل، رابط جدید */
async function viewCalcs() {
  const body = h('div', {}, skeleton(2, 160));
  shell('ماشین‌حساب داروخانه', body, { back: '#/' });
  try {
    const recs = await API.calcs();
    const zone = h('div', {});
    const pick = h('div', { class: 'chips mb' });
    function mount(r) {
      pick.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.dataset.id === r.id));
      zone.replaceChildren(buildCalc(r));
    }
    recs.forEach(r => pick.append(h('span', { class: 'chip', 'data-id': r.id, onclick: () => mount(r) }, r.name_fa)));
    function buildCalc(r) {
      const card = h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 4px;font-size:1rem' }, r.name_fa),
        h('p', { class: 'small', style: 'margin:0 0 10px' }, r.purpose));
      const inputs = r.inputs.map(name => {
        let kind = 'number';
        if (r.id === 'calc:convert' && name.includes('واحد')) kind = 'unit';
        if (kind === 'unit') {
          const sel = h('select', { class: 'inp' });
          [['g', 'گرم (g)'], ['mg', 'میلی‌گرم (mg)'], ['mcg', 'میکروگرم (mcg)'], ['l', 'لیتر (l)'], ['ml', 'میلی‌لیتر (ml)']].forEach(([v, t]) => sel.append(h('option', { value: v }, t)));
          return { name, el: sel, unit: true };
        }
        return { name, el: h('input', { class: 'inp', type: 'number', inputmode: 'decimal', step: 'any', placeholder: name }), unit: false };
      });
      inputs.forEach(f => card.append(h('div', { class: 'mb' }, h('div', { class: 'small' }, f.name), f.el)));
      const out = h('div', { class: 'mt' });
      const btn = h('button', { class: 'btn acc block' }, 'محاسبه');
      btn.onclick = () => {
        const num = el => parseFloat(String(el.value).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
        try {
          let res;
          const v = inputs.map(f => f.unit ? f.el.value : num(f.el));
          if (r.id === 'calc:qty') res = { val: v[0] * v[1], txt: `${v[0]} × ${v[1]} = ${v[0] * v[1]}` };
          else if (r.id === 'calc:packs') res = { val: Math.ceil(v[0] / v[1]), txt: `${v[0]} ÷ ${v[1]} = ${v[0] / v[1]} → گرد به بالا: ${Math.ceil(v[0] / v[1])}` };
          else if (r.id === 'calc:volume') res = { val: v[0] / v[1], txt: `${v[0]} ÷ ${v[1]} = ${(v[0] / v[1]).toFixed(2)} میلی‌لیتر` };
          else if (r.id === 'calc:days') res = { val: v[0] / v[1], txt: `${v[0]} ÷ ${v[1]} = ${(v[0] / v[1]).toFixed(1)} روز` };
          else if (r.id === 'calc:leftover') res = { val: v[0] - v[1] * v[2], txt: `${v[0]} − (${v[1]} × ${v[2]}) = ${v[0] - v[1] * v[2]}` };
          else if (r.id === 'calc:split') res = { val: v[0] * v[1], txt: `${v[0]} × ${v[1]} = ${v[0] * v[1]}` };
          else if (r.id === 'calc:reorder') res = { val: v[0] * v[1] + v[2], txt: `(${v[0]} × ${v[1]}) + ${v[2]} = ${v[0] * v[1] + v[2]}` };
          else if (r.id === 'calc:convert') {
            const from = v[1], to = v[2], x = v[0];
            const chain = { g: ['mg', 1000], mg: ['mcg', 1000], l: ['ml', 1000] };
            const inv = { mg: ['g', 1000], mcg: ['mg', 1000], ml: ['l', 1000] };
            let val = x, curU = from, path = [x + ' ' + from];
            let guard = 0;
            while (curU !== to && guard++ < 5) {
              if (chain[curU] && chain[curU][0] === to) { val *= chain[curU][1]; curU = to; path.push(val + ' ' + curU); }
              else if (inv[curU] && inv[curU][0] === to) { val /= inv[curU][1]; curU = to; path.push(val + ' ' + curU); }
              else if (chain[curU]) { val *= chain[curU][1]; curU = chain[curU][0]; path.push(val + ' ' + curU); }
              else if (inv[curU]) { val /= inv[curU][1]; curU = inv[curU][0]; path.push(val + ' ' + curU); }
              else break;
            }
            if (curU !== to) throw new Error('این تبدیل پشتیبانی نمی‌شود');
            res = { val, txt: path.join(' ← ') };
          }
          else throw new Error('فرمول این ابزار در اپ پیاده نشده؛ روش: ' + r.method);
          if (!isFinite(res.val)) throw new Error('ورودی نامعتبر');
          out.replaceChildren(h('div', { class: 'fb ok' }, h('h4', {}, 'نتیجه'), h('p', { style: 'margin:4px 0;font-size:1.05rem' }, faNum(String(res.txt))),
            h('div', { class: 'ref' }, 'کنترل معکوس را فراموش نکنید — خروجی ابزار جایگزین دقت شما نیست.')));
        } catch (e2) {
          out.replaceChildren(h('div', { class: 'fb no' }, h('h4', {}, 'روش این ابزار'), h('p', { style: 'margin:4px 0' }, r.method), h('p', { class: 'small' }, 'مثال: ' + r.example)));
        }
      };
      card.append(btn, out);
      card.append(h('p', { class: 'small mt' }, 'روش: ' + r.method + (r.example ? ' · مثال: ' + r.example : '')));
      return card;
    }
    mount(recs[0]);
    body.replaceChildren(pick, zone,
      h('p', { class: 'small dim' }, 'سیاست: هیچ عدد بیمه‌ای از حافظه نمی‌آید؛ درصدها همواره ورودی کاربر یا سامانهٔ رسمی‌اند.'));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewTerms() {
  const body = h('div', {}, skeleton(4, 60));
  shell('واژگان', body, { back: '#/' });
  try {
    const [recs, cur] = await Promise.all([API.terms(), API.curriculum()]);
    const byCh = {};
    for (const t of recs) (byCh[t.ch || '—'] ??= []).push(t);
    const secs = [];
    const names = Object.keys(byCh).sort((a, b) => {
      if (a === '—') return 1; if (b === '—') return -1;
      return (cur.chapters.find(c => c.id === a)?.order || 99) - (cur.chapters.find(c => c.id === b)?.order || 99);
    });
    for (const ch of names) {
      const name = ch === '—' ? 'عمومی' : (cur.chapters.find(c => c.id === ch)?.title_fa || ch);
      secs.push(h('div', { class: 'sec-title' }, name),
        ...byCh[ch].map(t => h('div', { class: 'card' },
          h('div', { class: 'flex', style: 'justify-content:space-between;gap:8px' },
            h('b', { style: 'font-size:.9rem' }, t.fa),
            t.en ? h('span', { class: 'chip num' }, t.en) : null),
          t.def ? h('div', { class: 'small mt' }, t.def) : null)));
    }
    body.replaceChildren(...secs);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

const URGL = { now: ['فوری — همین حالا', 'err'], normal: ['عادی', 'ok'] };
async function viewEscalation() {
  const body = h('div', {}, skeleton(3, 90));
  shell('قواعد ارجاع', body, { back: '#/' });
  try {
    const [recs, cur] = await Promise.all([API.esc(), API.curriculum()]);
    const order = { now: 0, normal: 1 };
    const groups = {};
    for (const r of recs) (groups[r.urg] ??= []).push(r);
    const secs = [];
    for (const [urg, list] of Object.entries(groups).sort((a, b) => (order[a[0]] ?? 9) - (order[b[0]] ?? 9))) {
      const [lbl, cls] = URGL[urg] || [urg, 'warn'];
      secs.push(h('div', { class: 'sec-title' }, lbl),
        ...list.map(r => h('div', { class: 'card' },
          h('b', { style: 'font-size:.88rem' }, r.trigger),
          h('div', { class: 'small mt' }, r.action),
          r.lesson ? h('div', { class: 'small dim mt' }, h('a', { href: lessonHref(cur, r.lesson) }, '📖 درس مرتبط')) : null)));
    }
    body.replaceChildren(...secs);
  } catch (e) { body.replaceChildren(errBox(e)); }
}
function lessonHref(cur, lessonId) {
  const ch = lessonId.split('-')[0];
  return `#/learn/${ch}/lesson/${lessonId}`;
}

async function viewErrpat() {
  const body = h('div', {}, skeleton(3, 90));
  shell('الگوهای خطا', body, { back: '#/' });
  try {
    const [recs, cur] = await Promise.all([API.errpat(), API.curriculum()]);
    const cats = [...new Set(recs.map(r => r.cat).filter(Boolean))].sort();
    const SEVL = { high: ['شدت بالا', 'err'], medium: ['شدت متوسط', 'warn'], low: ['شدت پایین', 'ok'] };
    const secs = [];
    for (const cat of (cats.length ? cats : [''])) {
      const list = recs.filter(r => (r.cat || '') === cat);
      secs.push(cat ? h('div', { class: 'sec-title' }, cat) : null,
        ...list.map(r => h('div', { class: 'card' },
          h('div', { class: 'flex', style: 'justify-content:space-between;gap:8px' },
            h('b', { style: 'font-size:.88rem' }, r.name_fa),
            r.sev && SEVL[r.sev] ? h('span', { class: 'chip ' + SEVL[r.sev][1] }, SEVL[r.sev][0]) : null),
          h('div', { class: 'small mt' }, r.desc),
          r.detect ? h('div', { class: 'small mt' }, h('b', {}, 'شناسایی: '), r.detect) : null,
          r.prevent ? h('div', { class: 'small mt' }, h('b', {}, 'پیشگیری: '), r.prevent) : null,
          r.lesson ? h('div', { class: 'small dim mt' }, h('a', { href: lessonHref(cur, r.lesson) }, '📖 درس مرتبط')) : null)));
    }
    body.replaceChildren(...secs);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewTips() {
  const body = h('div', {}, skeleton(4, 60));
  shell('پیشخوان‌داری', body, { back: '#/' });
  try {
    const [recs, cur] = await Promise.all([API.tips(), API.curriculum()]);
    const byCh = {};
    for (const t of recs) (byCh[t.ch || '—'] ??= []).push(t);
    const names = Object.keys(byCh).sort((a, b) => {
      if (a === '—') return 1; if (b === '—') return -1;
      return (cur.chapters.find(c => c.id === a)?.order || 99) - (cur.chapters.find(c => c.id === b)?.order || 99);
    });
    const secs = [];
    for (const ch of names) {
      const name = ch === '—' ? 'عمومی' : (cur.chapters.find(c => c.id === ch)?.title_fa || ch);
      secs.push(h('div', { class: 'sec-title' }, name),
        ...byCh[ch].map(t => h('div', { class: 'card' },
          h('b', { style: 'font-size:.88rem' }, t.t),
          h('div', { class: 'small mt' }, t.b))));
    }
    body.replaceChildren(...secs);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ============================================================
   تب تنظیمات + درباره (آخرین بخش)
   ============================================================ */
async function viewSettings() {
  const body = h('div', {});
  shell('تنظیمات', body);
  const s = settings.get();
  const segRow = (label, items, curV, onpick) => {
    const seg = h('div', { class: 'seg mt' }, ...items.map(it => {
      const b = h('button', { class: it.k === curV ? 'on' : '' }, it.t);
      b.onclick = () => { seg.querySelectorAll('button').forEach(x => x.classList.remove('on')); b.classList.add('on'); onpick(it.k); };
      return b;
    }));
    return h('div', { class: 'card mb' }, h('b', { style: 'font-size:.86rem' }, label), seg);
  };
  const swRow = (label, sub, curV, onpick) => {
    const inp = h('input', { type: 'checkbox', onchange: e => onpick(e.target.checked) });
    inp.checked = !!curV;
    return h('div', { class: 'form-row' }, h('div', { class: 'grow' }, h('label', { class: 't' }, label), sub ? h('div', { class: 's' }, sub) : null),
      h('label', { class: 'switch' }, inp, h('i')));
  };
  const ov = await prog.overall(await API.curriculum());
  const qz = store.get().quiz;
  const qAtt = Object.values(qz).reduce((a, x) => a + (x.attempts || 0), 0);
  const exportBtn = h('button', { class: 'btn block mb' }, 'برون‌بُری نسخهٔ پشتیبان (JSON)');
  exportBtn.onclick = () => {
    const payload = { app: 'rx-academy', version: '2.1.0', exported_at: new Date().toISOString(),
      progress: store.get(), settings: settings.get(),
      localRx: JSON.parse(localStorage.getItem('rx-academy-local-rx') || '[]') };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = h('a', { href: URL.createObjectURL(blob), download: 'rx-academy-backup-' + new Date().toISOString().slice(0, 10) + '.json' });
    document.body.append(a); a.click(); a.remove();
  };
  const importInp = h('input', { type: 'file', accept: '.json,application/json', style: 'display:none' });
  importInp.onchange = e => {
    const f = e.target.files[0]; if (!f) return;
    confirmSheet('بازیابی این نسخهٔ پشتیبان، داده‌های فعلی این دستگاه را جایگزین می‌کند. ادامه می‌دهید؟', async () => {
      try {
        const data = JSON.parse(await f.text());
        if (data.progress) localStorage.setItem('rx-academy-progress-v1', JSON.stringify(data.progress));
        if (data.settings) localStorage.setItem('rx-academy-settings-v1', JSON.stringify(data.settings));
        if (data.localRx) localStorage.setItem('rx-academy-local-rx', JSON.stringify(data.localRx));
        location.reload();
      } catch (err) { toast('فایل معتبر نیست.'); }
    });
    e.target.value = '';
  };
  const danger = (label, msg, fn) => {
    const b = h('button', { class: 'btn danger block mb' }, label);
    b.onclick = () => confirmSheet(msg, fn);
    return b;
  };
  body.replaceChildren(
    segRow('پوسته', [{ k: 'system', t: 'خودکار' }, { k: 'light', t: 'روشن' }, { k: 'dark', t: 'تیره' }], s.theme,
      k => settings.set({ theme: k })),
    segRow('اندازهٔ متن', [{ k: 1, t: 'معمولی' }, { k: 1.12, t: 'بزرگ‌تر' }, { k: 1.25, t: 'بزرگ‌ترین' }], s.fontScale,
      k => settings.set({ fontScale: k })),
    segRow('تراکم نمایش', [{ k: 'comfortable', t: 'راحت' }, { k: 'compact', t: 'فشرده' }], s.density,
      k => settings.set({ density: k })),
    segRow('پیشروی ترتیبی (آموزش و سنجش)', [{ k: 'sequential', t: 'ترتیبی' }, { k: 'free', t: 'آزاد' }], s.study.mode,
      k => settings.set({ study: { ...settings.get().study, mode: k } })),
    h('div', { class: 'card mb' },
      swRow('ترتیب تصادفی سؤالات', 'فقط داخل همان درس؛ پیش‌فرض خاموش', s.quiz.random, v => settings.set({ quiz: { ...settings.get().quiz, random: v } })),
      swRow('نمایش پیشرفت مطالعه', 'نوار و درصد پیشرفت در فصل‌ها، درس‌ها و آزمون‌ها', s.study.showProgress, v => settings.set({ study: { ...settings.get().study, showProgress: v } })),
      swRow('ادامهٔ خودکار از آخرین صفحه', 'کارت «ادامهٔ مطالعه» در پیشخوان و فصل‌ها', s.study.autoResume, v => settings.set({ study: { ...settings.get().study, autoResume: v } }))),
    h('div', { class: 'sec-title' }, 'داده‌های این دستگاه'),
    h('div', { class: 'card mb' },
      h('div', { class: 'flex', style: 'justify-content:space-between' }, h('b', { style: 'font-size:.86rem' }, 'پیشرفت مطالعه'), h('span', { class: 'chip acc num' }, faNum(ov.pctv) + '٪'))),
    exportBtn,
    h('button', { class: 'btn block mb', onclick: () => importInp.click() }, 'درون‌بُری نسخهٔ پشتیبان'),
    importInp,
    danger('پاک‌کردن پیشرفت مطالعه', 'تمام صفحات خوانده‌شده و «آخرین نقطهٔ مطالعه» پاک می‌شود. نتایج آزمون می‌مانند. مطمئن هستید؟',
      () => { store.clearStudy(); viewSettings(); }),
    danger('پاک‌کردن نتایج آزمون', 'تمام آمار و بهترین نمره‌های آزمون پاک می‌شود. مطمئن هستید؟',
      () => { store.clearQuiz(); viewSettings(); }),
    danger('بازنشانی کامل برنامه', 'پیشرفت، آزمون‌ها، نسخه‌های واردشده و همهٔ تنظیمات پاک می‌شود. این کار برگشت‌پذیر نیست. مطمئن هستید؟',
      () => { localStorage.removeItem('rx-academy-progress-v1'); localStorage.removeItem('rx-academy-settings-v1'); localStorage.removeItem('rx-academy-local-rx'); location.reload(); }),
    h('div', { class: 'card mt' },
      h('div', { class: 'sec-title', style: 'margin-top:4px' }, 'درباره'),
      h('b', {}, 'RX-ACADEMY — نسخه‌خوان حرفه‌ای'),
      h('p', { class: 'small' }, 'آموزش کامل نسخه‌خوانی و کار پیشخوان داروخانه برای هنرجویان و شاغلان؛ آفلاین، بدون ثبت‌نام، بدون سرور.'),
      h('p', { class: 'small dim' }, DISCLAIMER),
      h('p', { class: 'small dim' }, 'نسخهٔ ۲٫۱ · داده‌های مستند و شفاف · پروانهٔ محتوا در فایل LICENSES.md · کد و گزارش‌ها در پوشهٔ docs')));
}


/* تأیید دومرحله‌ای برای عملیات خطرناک */
function confirmSheet(msg, onYes) {
  const close = () => { sheet.classList.remove('show'); scrim.classList.remove('show'); setTimeout(() => { sheet.remove(); scrim.remove(); }, 230); };
  const scrim = h('div', { class: 'scrim', onclick: close });
  const sheet = h('div', { class: 'sheet', role: 'dialog', 'aria-label': 'تأیید عملیات' },
    h('div', { class: 'grab' }),
    h('div', { class: 'sheet-body' },
      h('h3', {}, 'تأیید عملیات'),
      h('p', { class: 'small' }, msg),
      h('div', { class: 'grid2 mt' },
        h('button', { class: 'btn danger', onclick: () => { close(); onYes(); } }, 'بله، انجام شود'),
        h('button', { class: 'btn', onclick: close }, 'انصراف'))));
  document.body.append(scrim, sheet);
  requestAnimationFrame(() => { sheet.classList.add('show'); scrim.classList.add('show'); });
}

/* ============================================================
   جست‌وجو (صفحهٔ کمکی — بدون تبلیغ عددی)
   ============================================================ */
async function viewSearch() {
  const body = h('div', {});
  shell('جست‌وجو', body, { back: true });
  const inp = h('input', { class: 'inp mb', type: 'search', placeholder: 'نام دارو، اختصار، واژه یا عنوان صفحه…', autofocus: true });
  const res = h('div', {});
  body.replaceChildren(inp, res);
  let timer;
  inp.oninput = () => { clearTimeout(timer); timer = setTimeout(run, 220); };
  async function run() {
    const t = inp.value.trim();
    if (t.length < 2) { res.replaceChildren(h('div', { class: 'empty' }, 'حداقل دو حرف بنویسید.')); return; }
    res.replaceChildren(spinner('در حال جست‌وجو…'));
    try {
      const [drugs, abbr, terms, cur] = await Promise.all([API.drugs(), API.abbr(), API.terms(), API.curriculum()]);
      const tl = t.toLowerCase();
      const dHits = drugs.filter(d => norm(d.name_fa).includes(t) || norm(d.name_en).includes(tl) || norm(d.atc_code).includes(tl)).slice(0, 30);
      const aHits = abbr.filter(r => norm(r.symbol).includes(tl) || norm(r.fa).includes(t)).slice(0, 20);
      const tHits = terms.filter(r => norm(r.fa).includes(t) || norm(r.en).includes(tl) || norm(r.def).includes(t)).slice(0, 20);
      const pHits = [];
      for (const ch of cur.chapters) {
        const sh = await API.chapter(ch.id);
        for (const p of sh.pages) if (norm(p.title_fa).includes(t)) pHits.push({ p, ch });
        if (pHits.length >= 15) break;
      }
      const sec = (title, items, rowFn) => items.length ? h('div', { class: 'mb' }, h('div', { class: 'sec-title' }, title), items.map(rowFn)) : null;
      res.replaceChildren(...[
        sec('دارو', dHits, d => {
          const r = h('div', { class: 'card click' }, h('div', { class: 'item-head' }, h('div', { class: 'item-title' }, d.name_fa), h('span', { class: 'chip num' }, d.name_en)));
          r.onclick = () => location.hash = '#/pharmacy/drug/' + encodeURIComponent(d.id); return r;
        }),
        sec('اختصار', aHits, r => h('div', { class: 'card' }, h('b', {}, r.symbol), h('div', { class: 'small' }, r.fa))),
        sec('واژه', tHits, r => h('div', { class: 'card' }, h('b', {}, r.fa), h('div', { class: 'small' }, r.def))),
        sec('صفحهٔ کتابچه', pHits, x => {
          const r = h('div', { class: 'card click' }, h('div', { class: 'item-head' }, h('div', { class: 'item-title' }, x.p.title_fa), h('span', { class: 'chip' }, x.ch.title_fa)));
          r.onclick = () => location.hash = `#/learn/${x.ch.id}/lesson/${x.p.lesson_id}?p=${x.p.id}`; return r;
        }),
        (!dHits.length && !aHits.length && !tHits.length && !pHits.length) ? h('div', { class: 'empty' }, 'چیزی پیدا نشد.') : null
      ].filter(Boolean));
    } catch (e) { res.replaceChildren(errBox(e)); }
  }
}

/* ============================================================
   روتر + تغییرمسیرهای نشانی‌های قدیمی
   ============================================================ */
const REDIRECTS = [
  [/^#\/book$/, () => '#/learn'],
  [/^#\/book\/(C\d+)\/(\d+)$/, m => `#/learn/${m[1]}`],
  [/^#\/quiz$/, () => '#/assess/quiz'],
  [/^#\/quiz\/(C\d+)$/, m => `#/assess/quiz/${m[1]}`],
  [/^#\/drugs$/, () => '#/pharmacy/drugs'],
  [/^#\/drug\/(.+)$/, m => `#/pharmacy/drug/${m[1]}`],
  [/^#\/forms\/?$/, () => '#/pharmacy/forms'],
  [/^#\/form\/(.+)$/, m => `#/pharmacy/forms/${m[1]}`],
  [/^#\/routes\/?$/, () => '#/pharmacy/routes'],
  [/^#\/route\/(.+)$/, m => `#/pharmacy/routes/${m[1]}`],
  [/^#\/scenarios$/, () => '#/assess/scenarios'],
  [/^#\/scenarios\/(.+)$/, m => `#/assess/scenarios/${m[1]}`],
  [/^#\/tools$/, () => '#/'],
  [/^#\/abbr$/, () => '#/rx/abbr'],
  [/^#\/about$/, () => '#/settings'],
  [/^#\/progress$/, () => '#/'],
];
const ROUTES = [
  [/^#\/$/, () => viewCounter()],
  [/^#\/learn$/, () => viewLearn()],
  [/^#\/learn\/(C\d+)$/, m => viewChapter(m[1])],
  [/^#\/learn\/(C\d+)\/lesson\/([^/?]+)/, (m, q) => viewLesson(m[1], decodeURIComponent(m[2]), q.p)],
  [/^#\/assess$/, () => viewAssess()],
  [/^#\/assess\/quiz$/, () => viewQuizChapters()],
  [/^#\/assess\/quiz\/(C\d+)$/, m => viewQuizChapter(m[1])],
  [/^#\/assess\/scenarios$/, () => viewScenarios()],
  [/^#\/assess\/scenarios\/(.+)$/, m => viewScenario(m[1])],
  [/^#\/pharmacy$/, () => viewPharmacy()],
  [/^#\/pharmacy\/drugs$/, () => viewDrugs()],
  [/^#\/pharmacy\/drug\/(.+)$/, m => viewDrug(m[1])],
  [/^#\/pharmacy\/forms$/, () => viewForms()],
  [/^#\/pharmacy\/forms\/(.+)$/, m => viewForm(m[1])],
  [/^#\/pharmacy\/routes$/, () => viewRoutes()],
  [/^#\/pharmacy\/routes\/(.+)$/, m => viewRoute(m[1])],
  [/^#\/rx$/, () => viewRx()],
  [/^#\/rx\/prescriptions$/, () => viewPrescriptions()],
  [/^#\/rx\/abbr$/, () => viewAbbr()],
  [/^#\/calc$/, () => viewCalcs()],
  [/^#\/terms$/, () => viewTerms()],
  [/^#\/escalation$/, () => viewEscalation()],
  [/^#\/errpat$/, () => viewErrpat()],
  [/^#\/tips$/, () => viewTips()],
  [/^#\/settings$/, () => viewSettings()],
  [/^#\/search$/, () => viewSearch()],
];
function boot() {
  applyLook();
  const mq = mqDark();
  (mq.addEventListener || mq.addListener)?.call(mq, 'change', () => { if (settings.get().theme === 'system') applyLook(); });
  const route = () => {
    const hash = location.hash || '#/';
    for (const [re, fn] of REDIRECTS) {
      const m = hash.match(re);
      if (m) { location.replace(fn(m)); return; }
    }
    const q = {};
    const [path, qs] = hash.split('?');
    if (qs) new URLSearchParams(qs).forEach((v, k) => q[k] = v);
    for (const [re, fn] of ROUTES) {
      const m = path.match(re);
      if (m) return fn(m, q);
    }
    location.replace('#/');
  };
  addEventListener('hashchange', route);
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
  route();
}
document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', boot) : boot();
