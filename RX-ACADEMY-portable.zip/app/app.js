/* RX-ACADEMY — offline-first RTL PWA (vanilla JS, zero dependencies, no runtime AI, no analytics) */
'use strict';

/* ---------------- tiny dom helpers ---------------- */
const $ = (s, el = document) => el.querySelector(s);
const h = (tag, attrs = {}, ...kids) => {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined && v !== false) el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  return el;
};
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
/* سلب مسئولیت ثابت (TDD-08): نمایش در ورودی، پایین رکورد دارویی و نتیجهٔ آزمون */
const DISCLAIMER = 'این برنامه یک منبع آموزشی برای یادگیری نسخه‌خوانی و کار در داروخانه است؛ نه راهنمای درمان و نه جایگزین قضاوت داروساز یا پزشک. هیچ‌گاه بر پایهٔ محتوای این برنامه برای بیمارِ مشخص تصمیم نگیرید. در هر مورد تردید، به داروساز مسئول ارجاع دهید و آخرین بخشنامه‌های رسمی را ملاک قرار دهید.';
const faNum = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
const pct = (a, b) => b ? Math.round((a / b) * 100) : 0;

/* ---------------- local store ---------------- */
const STORE_KEY = 'rx-academy-progress-v1';
const store = (() => {
  let d = {};
  try { d = JSON.parse(localStorage.getItem(STORE_KEY) || '{}'); } catch (e) { d = {}; }
  d.bookRead ??= {}; d.quiz ??= {}; d.calcLog ??= [];
  return {
    get: () => d,
    save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(d)); } catch (e) {} },
    markPage(id) { d.bookRead[id] = 1; this.save(); },
    quizStats(ch) { return d.quiz[ch] ??= { attempts: 0, answered: 0, correct: 0, best: 0 }; },
    recordQuiz(ch, answered, correct) {
      const s = this.quizStats(ch);
      s.attempts++; s.answered += answered; s.correct += correct;
      s.best = Math.max(s.best, answered ? pct(correct, answered) : 0);
      this.save();
    }
  };
})();

/* ---------------- data layer (manifest-driven, no caps) ---------------- */
const cache = {};
async function jfetch(url) {
  if (cache[url]) return cache[url];
  const r = await fetch(url, { cache: 'no-cache' });
  if (!r.ok) throw new Error('fetch failed: ' + url);
  const j = await r.json();
  cache[url] = j;
  return j;
}
const API = {
  manifest: () => jfetch('data/manifest.json'),
  curriculum: () => jfetch('data/curriculum.json'),
  chapter: id => jfetch(`data/curriculum/${id}.json`),
  questions: ch => jfetch(`data/questions/questions-${String(ch).replace(/^C/, '').padStart(2, '0')}.json`).then(d => d.questions),
  drugs: () => jfetch('data/drugs.json').then(d => d.records),
  forms: () => jfetch('data/forms.json').then(d => d.records),
  routes: () => jfetch('data/routes.json').then(d => d.records),
  calcs: () => jfetch('data/calculators.json').then(d => d.records),
  abbr: () => jfetch('data/abbreviations/abbr-01-sig.json').then(d => d.records),
  terms: async () => {
    const m = await API.manifest();
    const files = m.banks.terms.files || [];
    const all = [];
    for (const f of files) all.push(...(await jfetch(/^data\//.test(f) ? f : `data/terms/${f}`)).records);
    return all;
  },
  scenarios: async () => {
    const m = await API.manifest();
    const all = [];
    for (const f of (m.banks.scenarios.files || [])) all.push(...(await jfetch(/^data\//.test(f) ? f : `data/scenarios/${f}`)).records);
    return all;
  },
  esc: () => jfetch('data/escalation-rules.json').then(d => d.records),
  tips: () => jfetch('data/tips.json').then(d => d.records),
  errpat: () => jfetch('data/error-patterns.json').then(d => d.records),
  sources: () => jfetch('data/sources.json').then(d => d.sources),
  page: path => fetch(path, { cache: 'no-cache' }).then(r => r.ok ? r.text() : Promise.reject(r.status))
};

/* ---------------- markdown mini-renderer ---------------- */
function mdToHtml(src) {
  const lines = src.replace(/\r/g, '').split('\n');
  let html = '', inList = false, inQuote = false;
  const inline = t => esc(t)
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/«([^»]+)»/g, '«<b>$1</b>»')
    .replace(/`([^`]+)`/g, '<code>$1</code>');
  const close = () => { if (inList) { html += '</ul>'; inList = false; } if (inQuote) { html += '</blockquote>'; inQuote = false; } };
  for (const raw of lines) {
    const line = raw.trimEnd();
    if (!line.trim()) { close(); continue; }
    if (line.startsWith('### ')) { close(); html += `<h3>${inline(line.slice(4))}</h3>`; }
    else if (line.startsWith('## ')) { close(); html += `<h2>${inline(line.slice(3))}</h2>`; }
    else if (line.startsWith('# ')) { close(); html += `<h1>${inline(line.slice(2))}</h1>`; }
    else if (line.startsWith('> ')) {
      if (inList) { html += '</ul>'; inList = false; }
      if (!inQuote) { html += '<blockquote>'; inQuote = true; }
      html += inline(line.slice(2)) + '<br>';
    }
    else if (line.startsWith('- ')) {
      if (inQuote) { html += '</blockquote>'; inQuote = false; }
      if (!inList) { html += '<ul>'; inList = true; }
      html += `<li>${inline(line.slice(2))}</li>`;
    }
    else { close(); html += `<p>${inline(line)}</p>`; }
  }
  close();
  return html;
}

/* ---------------- icons (inline SVG) ---------------- */
const I = {
  home: '<svg viewBox="0 0 24 24"><path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/></svg>',
  book: '<svg viewBox="0 0 24 24"><path d="M4 5a2 2 0 012-2h14v18H6a2 2 0 01-2-2z"/><path d="M20 17H6a2 2 0 000 4"/></svg>',
  quiz: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 114 2c-.8.7-1.5 1.2-1.5 2.2"/><path d="M12 17h.01"/></svg>',
  pill: '<svg viewBox="0 0 24 24"><rect x="3" y="9" width="18" height="7" rx="3.5" transform="rotate(-35 12 12.5)"/><path d="M8.5 8l7 8.5"/></svg>',
  tools: '<svg viewBox="0 0 24 24"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h3M13 11h3M8 15h3M13 15h3M8 19h3"/></svg>'
};
const navItems = [
  { id: '', label: 'خانه', icon: I.home },
  { id: 'book', label: 'کتابچه', icon: I.book },
  { id: 'quiz', label: 'آزمون', icon: I.quiz },
  { id: 'drugs', label: 'داروها', icon: I.pill },
  { id: 'tools', label: 'ابزار', icon: I.tools }
];

/* ---------------- shell ---------------- */
const app = $('#app');
function shell(title, body, crumb) {
  app.replaceChildren(
    h('div', { class: 'topbar' },
      h('div', { class: 'wrap row' },
        h('a', { class: 'logo', href: '#/' }, h('span', { class: 'dot' }, '℞'), 'RX-ACADEMY'),
        crumb ? h('span', { class: 'crumb grow' }, crumb) : h('span', { class: 'grow' }),
        h('a', { class: 'tag', href: '#/about' }, 'درباره')
      )
    ),
    h('main', { class: 'wrap', style: 'padding-top:14px' }, body),
    h('nav', { class: 'bnav' }, navItems.map(n =>
      h('a', { href: '#/' + n.id, class: location.hash.slice(2).split('/')[0] === n.id ? 'on' : '' },
        h('span', { html: n.icon }), n.label)
    ))
  );
  document.title = title ? `${title} — RX-ACADEMY` : 'RX-ACADEMY';
  window.scrollTo(0, 0);
}
const spinner = (msg = 'در حال بارگذاری…') => h('div', { class: 'empty' }, msg);
const errBox = e => h('div', { class: 'card' },
  h('b', {}, 'خطا در بارگذاری داده'),
  h('p', { class: 'small' }, String(e && e.message || e)),
  h('p', { class: 'small' }, 'این اپ آفلاین است؛ اگر اولین بار است، یک‌بار به اینترنت وصل شوید تا فایل‌ها کش شوند، یا از نصب محلی استفاده کنید.'));

/* ---------------- views: home ---------------- */
async function viewHome() {
  const body = h('div', {}, spinner());
  shell('پیشخوان آموزش نسخه‌خوانی', body);
  try {
    const [m, cur] = await Promise.all([API.manifest(), API.curriculum()]);
    const b = m.banks;
    const st = (title, v) => h('div', { class: 'stat' }, h('b', {}, faNum(v)), h('span', {}, title));
    body.replaceChildren(
      h('div', { class: 'card' },
        h('h1', { style: 'font-size:1.25rem;margin:0 0 6px' }, 'نسخه‌خوانی و کار در داروخانه'),
        h('p', { class: 'small', style: 'margin:0' },
          'دورهٔ کامل آفلاین برای تکنسین پیشخوان — کتابچهٔ ',
          faNum(cur.pages), ' صفحه‌ای، بانک ',
          faNum(b.questions.count), ' سؤالی، کتابخانهٔ ',
          faNum(b.drugs.count), ' دارو و ابزارهای پیشخوان. فارسی، راست‌چین، بدون نیاز به اینترنت پس از بارگذاری اول.'),
        h('p', { class: 'small', style: 'margin:8px 0 0;color:var(--dim)' }, DISCLAIMER)),
      h('div', { class: 'grid3 mb' },
        st('صفحهٔ کتابچه', cur.pages),
        st('سؤال تمرینی', b.questions.count),
        st('دارو (ژنریک)', b.drugs.count)),
      h('div', { class: 'grid3 mb' },
        st('واژگان', b.terms.count),
        st('اختصار نسخه', b.abbreviations.count),
        st('سناریوی تمرین', b.scenarios.count)),
      h('div', { class: 'grid2' },
        h('a', { class: 'tile', href: '#/book' }, h('div', { class: 'ico' }, '📖'), h('div', { class: 't' }, 'خواندن کتابچه'), h('div', { class: 's' }, '۱۵ فصل · ۸۲ درس · ۲۴۶ صفحه')),
        h('a', { class: 'tile', href: '#/quiz' }, h('div', { class: 'ico' }, '🧪'), h('div', { class: 't' }, 'آزمون فصل‌ها'), h('div', { class: 's' }, '۸۰۰ سؤال با بازخورد')),
        h('a', { class: 'tile', href: '#/drugs' }, h('div', { class: 'ico' }, '💊'), h('div', { class: 't' }, 'کتابخانهٔ دارو'), h('div', { class: 's' }, '۹۶۵ داروی ژنریک با کد رسمی')),
        h('a', { class: 'tile', href: '#/tools' }, h('div', { class: 'ico' }, '🧮'), h('div', { class: 't' }, 'ابزار پیشخوان'), h('div', { class: 's' }, 'ماشین‌حساب‌ها و مرجع‌ها')),
        h('a', { class: 'tile', href: '#/rx' }, h('div', { class: 'ico' }, '🗂️'), h('div', { class: 't' }, 'گنجینهٔ نسخه'), h('div', { class: 's' }, 'صفر تصویر — موتور و واردسازی')),
        h('a', { class: 'tile', href: '#/search' }, h('div', { class: 'ico' }, '🔎'), h('div', { class: 't' }, 'جست‌وجوی سراسری'), h('div', { class: 's' }, 'دارو، اختصار، واژه، صفحه'))
    ));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------------- views: book ---------------- */
async function viewBook() {
  const body = h('div', {}, spinner());
  shell('کتابچه', body, 'فهرست کامل');
  try {
    const cur = await API.curriculum();
    const readSet = store.get().bookRead;
    const box = h('div', { class: 'card pad0' });
    cur.chapters.forEach(ch => {
      const chEl = h('div', { class: 'toc-ch' });
      const head = h('button', {},
        h('span', { class: 'flex' }, h('span', { class: 'num' }, faNum(ch.order)), h('span', {}, ch.title_fa)),
        h('span', { class: 'flex' }, h('span', { class: 'tag' }, faNum(ch.lesson_ids.length) + ' درس'), h('span', { class: 'chev' }, '◂')));
      const bd = h('div', { class: 'toc-body' });
      head.onclick = async () => {
        chEl.classList.toggle('open');
        if (chEl.classList.contains('open') && !bd.dataset.loaded) {
          bd.dataset.loaded = 1;
          bd.append(spinner());
          const shard = await API.chapter(ch.id);
          bd.replaceChildren();
          shard.lessons.forEach(ls => {
            bd.append(h('div', { class: 'lesson-h' }, ls.title_fa));
            shard.pages.filter(p => p.lesson_id === ls.id).forEach(p => {
              const row = h('div', { class: 'pagerow' + (readSet[p.id] ? ' done' : '') },
                h('span', { class: 'rd' }), h('span', { class: 'grow' }, p.title_fa),
                h('span', { class: 'small' }, `~${faNum(p.est_words)} واژه`));
              row.onclick = () => location.hash = `#/book/${ch.id}/${p.id}`;
              bd.append(row);
            });
          });
        }
      };
      chEl.append(head, bd);
      box.append(chEl);
    });
    body.replaceChildren(
      h('div', { class: 'flex mb' },
        h('span', { class: 'tag acc' }, faNum(cur.chapters.length) + ' فصل'),
        h('span', { class: 'tag acc' }, faNum(cur.lessons) + ' درس'),
        h('span', { class: 'tag acc' }, faNum(cur.pages) + ' صفحه'),
        h('span', { class: 'tag' }, 'پیشرفت خواندن ذخیره می‌شود')),
      box);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewPage(chId, pageId) {
  const body = h('div', {}, spinner());
  shell('کتابچه', body);
  try {
    const shard = await API.chapter(chId);
    const cur = await API.curriculum();
    const chMeta = cur.chapters.find(c => c.id === chId);
    const pages = shard.pages;
    const idx = pages.findIndex(p => p.id === pageId);
    const page = pages[idx];
    if (!page) { body.replaceChildren(h('div', { class: 'empty' }, 'صفحه پیدا نشد.')); return; }
    const lesson = shard.lessons.find(l => l.id === page.lesson_id);
    const md = await API.page(page.path);
    store.markPage(page.id);
    const card = h('div', { class: 'card' }, h('div', { class: 'prose', html: mdToHtml(md) }));
    const nav = h('div', { class: 'pager-nav' });
    if (idx > 0) nav.append(h('button', { onclick: () => location.hash = `#/book/${chId}/${pages[idx - 1].id}` }, '→ صفحهٔ قبل'));
    nav.append(h('button', { class: 'acc', onclick: () => location.hash = '#/book' }, 'فهرست'));
    if (idx < pages.length - 1) nav.append(h('button', { onclick: () => location.hash = `#/book/${chId}/${pages[idx + 1].id}` }, 'صفحهٔ بعد ←'));
    body.replaceChildren(
      h('div', { class: 'flex mb' },
        h('a', { class: 'tag', href: '#/book' }, chMeta ? chMeta.title_fa : chId),
        h('span', { class: 'tag' }, lesson ? lesson.title_fa : ''),
        h('span', { class: 'tag acc' }, `صفحهٔ ${faNum(idx + 1)} از ${faNum(pages.length)}`)),
      card, nav);
    document.title = `${page.title_fa} — RX-ACADEMY`;
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------------- quiz engine ---------------- */
function shuffle(a) { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; }

async function viewQuiz() {
  const body = h('div', {}, spinner());
  shell('آزمون', body, 'بانک سؤال');
  try {
    const m = await API.manifest();
    const cur = await API.curriculum();
    const qstats = store.get().quiz;
    const list = h('div', { class: 'card pad0' });
    for (const ch of cur.chapters) {
      const f = `questions-${ch.order < 10 ? '0' + ch.order : ch.order}.json`;
      const bank = (m.banks.questions.files || []).includes(f);
      const s = qstats[ch.id];
      const right = h('span', { class: 'flex' });
      if (s && s.attempts) right.append(h('span', { class: 'tag acc' }, `بهترین ${faNum(s.best)}٪`));
      right.append(h('span', { class: 'chev' }, '◂'));
      const row = h('div', { class: 'rowline click' },
        h('div', {}, h('b', { style: 'font-size:.9rem' }, `${faNum(ch.order)}. ${ch.title_fa}`),
          h('div', { class: 'small' }, bank ? 'آزمون فصلی + مرور سؤالات' : 'به‌زودی')),
        right);
      if (bank) row.onclick = () => location.hash = `#/quiz/${ch.id}`;
      else row.style.opacity = .55;
      list.append(row);
    }
    body.replaceChildren(
      h('div', { class: 'flex mb' },
        h('span', { class: 'tag acc' }, `${faNum(m.banks.questions.count)} سؤال`),
        h('span', { class: 'tag' }, '≥۸ سؤال برای هر درس · ≥۳ سؤال برای هر هدف')),
      list);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewQuizChapter(chId) {
  const body = h('div', {}, spinner());
  shell('آزمون فصل', body);
  try {
    const [qs, shard, cur] = await Promise.all([API.questions(chId), API.chapter(chId), API.curriculum()]);
    const chMeta = cur.chapters.find(c => c.id === chId);
    const byLesson = {};
    qs.forEach(q => (byLesson[q.lesson_id] ??= []).push(q));
    const s = store.quizStats(chId);
    const opts = { n: Math.min(10, qs.length) };
    const cfg = h('div', { class: 'card' },
      h('h2', { style: 'margin:0 0 4px;font-size:1.05rem' }, chMeta ? chMeta.title_fa : chId),
      h('p', { class: 'small', style: 'margin:0 0 10px' }, `${faNum(qs.length)} سؤال در ${faNum(Object.keys(byLesson).length)} درس این فصل`),
      h('div', { class: 'flex mb' },
        ...[5, 10, 20, 0].map(k => h('span', {
          class: 'chip' + (k === opts.n ? ' on' : ''), onclick: ev => {
            opts.n = k === 0 ? qs.length : k;
            cfg.querySelectorAll('.chip').forEach(c => c.classList.remove('on'));
            ev.target.classList.add('on');
          }
        }, k === 0 ? 'همهٔ فصل' : `${faNum(k)} سؤالی`))),
      h('div', { class: 'flex mb small' },
        h('label', {}, h('input', { type: 'checkbox', checked: true, onchange: e => opts.mix = e.target.checked }), ' مخلوط‌کردن ترتیب سؤالات')),
      s.attempts ? h('p', { class: 'small' }, `تلاش‌های شما: ${faNum(s.attempts)} · پاسخ‌ها: ${faNum(s.answered)} · درست: ${faNum(s.correct)} · بهترین: ${faNum(s.best)}٪`) : null,
      h('button', { class: 'btn acc', style: 'flex:none;width:100%', onclick: () => startSession(chId, qs, opts) }, 'شروع آزمون'));
    const lessonBox = h('div', { class: 'card pad0 mt' });
    Object.entries(byLesson).forEach(([lid, arr]) => {
      const ls = shard.lessons.find(l => l.id === lid);
      const row = h('div', { class: 'rowline click' },
        h('div', {}, h('b', { style: 'font-size:.86rem' }, ls ? ls.title_fa : lid), h('div', { class: 'small' }, faNum(arr.length) + ' سؤال')),
        h('span', { class: 'chev' }, '◂'));
      row.onclick = () => startSession(chId, arr, { n: arr.length, title: ls ? ls.title_fa : lid });
      lessonBox.append(row);
    });
    body.replaceChildren(cfg, h('div', { class: 'small mb' }, 'یا مرور درس‌به‌درس:'), lessonBox);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

function startSession(chId, pool, opts) {
  let items = shuffle(pool).slice(0, opts.n);
  if (opts.mix === false) items = pool.slice(0, opts.n);
  const st = { i: 0, correct: 0, answered: 0, answers: [] };
  renderQ(chId, items, st, opts);
}

function renderQ(chId, items, st, opts) {
  const q = items[st.i];
  const prog = h('div', { class: 'mb' },
    h('div', { class: 'flex mb small' },
      h('span', { class: 'tag acc' }, `سؤال ${faNum(st.i + 1)} از ${faNum(items.length)}`),
      h('span', { class: 'tag' }, q.practice_type),
      h('span', { class: 'tag' }, 'عمق ' + q.depth_level),
      h('span', { class: 'grow' }),
      h('a', { href: `#/quiz/${chId}`, class: 'tag', onclick: e => { e.preventDefault(); viewQuizChapter(chId); } }, '✕ خروج')),
    h('div', { class: 'progress' }, h('i', { style: `width:${pct(st.i, items.length)}%` })));
  const meta = h('div', { class: 'small mb' },
    (q.lo_ids || []).map(lo => h('span', { class: 'tag', style: 'margin-inline-end:4px' }, lo)).flat());
  const box = h('div', { class: 'qcard' });
  const cont = h('div', {}, prog, meta, box);
  shell('آزمون', cont, 'پرسش');

  const finish = () => {
    store.recordQuiz(chId, st.answered, st.correct);
    const ok = pct(st.correct, st.answered || 1);
    const verdict = ok >= 80 ? ['🌟 عالی — آمادهٔ فصل بعد هستید', 'ok'] : ok >= 50 ? ['👍 قابل قبول — فصل را مرور کنید', 'warn'] : ['📖 نیاز به مطالعهٔ دوبارهٔ این فصل دارید', 'err'];
    const bars = h('div', {});
    shell('نتیجهٔ آزمون', h('div', {},
      h('div', { class: 'card center' },
        h('h2', { style: 'margin:0' }, `${faNum(st.correct)} از ${faNum(st.answered)} درست`),
        h('div', { class: 'progress mt mb' }, h('i', { style: `width:${ok}%;background:${ok >= 80 ? 'var(--ok)' : ok >= 50 ? 'var(--warn)' : 'var(--err)'}` })),
        h('p', {}, verdict[0]),
        h('p', { class: 'small', style: 'color:var(--dim)' }, DISCLAIMER)),
      h('div', { class: 'grid2' },
        h('a', { class: 'tile', href: `#/quiz/${chId}`, onclick: e => { e.preventDefault(); viewQuizChapter(chId); } }, h('div', { class: 't' }, 'آزمون دوباره')),
        h('a', { class: 'tile', href: '#/quiz' }, h('div', { class: 't' }, 'فصل‌های دیگر')),
        h('a', { class: 'tile', href: '#/book' }, h('div', { class: 't' }, 'مطالعهٔ کتابچه')),
        h('a', { class: 'tile', href: '#/' }, h('div', { class: 't' }, 'خانه')))));
  };
  const next = () => { st.i++; st.i < items.length ? renderQ(chId, items, st, opts) : finish(); };

  const fbBlock = (good, fb) => {
    const d = h('div', { class: 'fb ' + (good ? 'ok' : 'no') }, h('h4', {}, good ? '✅ درست است' : '✖ درست نبود'));
    if (fb) {
      if (good && fb.why_correct) d.append(h('p', { style: 'margin:4px 0' }, fb.why_correct));
      if (!good && fb.why_correct) d.append(h('p', { style: 'margin:4px 0' }, 'پاسخ درست: ', fb.why_correct));
      const notes = fb.wrong_option_notes || [];
      const ul = h('ul', {});
      notes.filter(Boolean).forEach(n => ul.append(h('li', {}, n)));
      if (ul.childNodes.length) d.append(ul);
      if (fb.refer_fa) d.append(h('div', { class: 'ref' }, '📎 ' + fb.refer_fa));
    }
    return d;
  };

  /* --- flashcard --- */
  if (q.practice_type === 'flashcard') {
    const card = h('div', { class: 'flip' },
      h('div', { class: 'inner' },
        h('div', { class: 'face' }, q.front_fa),
        h('div', { class: 'face back' }, q.back_fa)));
    card.onclick = () => card.classList.toggle('flipped');
    const grade = h('div', { class: 'flex mt' },
      h('button', { class: 'btn', style: 'flex:1', onclick: () => { st.answered++; } }, '🤔 بلد نبودم'),
      h('button', { class: 'btn acc', style: 'flex:1', onclick: () => { st.answered++; st.correct++; } }, '✅ بلد بودم'));
    let graded = false;
    const done = h('button', { class: 'btn mt', style: 'display:none;width:100%', onclick: next }, 'سؤال بعد ←');
    grade.querySelectorAll('button').forEach(b => b.addEventListener('click', () => {
      if (graded) return; graded = true;
      grade.style.display = 'none'; done.style.display = 'block';
      box.append(fbBlock(true, q.feedback_fa));
    }));
    box.append(h('p', { style: 'margin-top:0' }, q.front_fa ? '' : ''), card, h('p', { class: 'small center' }, 'برای دیدن پاسخ، روی کارت بزنید'), grade, done);
    return;
  }

  /* --- calculation with numeric answer --- */
  if (q.practice_type === 'calculation' && q.answer_type === 'number') {
    const inp = h('input', { type: 'number', inputmode: 'decimal', placeholder: 'پاسخ عددی…', step: 'any' });
    const btn = h('button', { class: 'btn acc mt', style: 'width:100%' }, 'بررسی پاسخ');
    const zone = h('div', {});
    let answered = false;
    btn.onclick = () => {
      if (answered) return next();
      answered = true; st.answered++;
      const v = parseFloat(String(inp.value).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
      const good = !isNaN(v) && Math.abs(v - q.correct_answer) <= (q.tolerance ?? 0.0001);
      if (good) st.correct++;
      inp.disabled = true;
      btn.textContent = 'سؤال بعد ←';
      zone.append(fbBlock(good, q.feedback_fa),
        h('p', { class: 'small' }, `پاسخ درست: ${faNum(q.correct_answer)}` + (q.tolerance ? ` (تحمل ${faNum(q.tolerance)})` : '')));
    };
    box.append(h('p', { style: 'margin-top:0' }, q.stem_fa), inp, btn, zone);
    return;
  }

  /* --- calculation with choices --- */
  if (q.practice_type === 'calculation' && q.answer_type === 'choice') {
    return renderChoice(q, box, q.options_fa, q.correct_answer, false, next, st, fbBlock);
  }

  /* --- multi select --- */
  if ((q.practice_formats || []).includes('mcq_multi')) {
    const sel = new Set();
    const zone = h('div', {});
    const opts = q.options_fa.map((o, i) => {
      const mk = h('span', { class: 'mk' }, '☐');
      const el = h('div', { class: 'opt' }, mk, h('span', {}, o));
      el.onclick = () => {
        if (el.classList.contains('dis')) return;
        sel.has(i) ? sel.delete(i) : sel.add(i);
        el.classList.toggle('sel');
        mk.textContent = sel.has(i) ? '☑' : '☐';
      };
      return el;
    });
    let answered = false;
    const btn = h('button', { class: 'btn acc mt', style: 'width:100%' }, 'بررسی پاسخ');
    btn.onclick = () => {
      if (answered) return next();
      answered = true; st.answered++;
      const want = new Set(q.correct_indices);
      const good = sel.size === want.size && [...sel].every(i => want.has(i));
      if (good) st.correct++;
      opts.forEach((el, i) => {
        el.classList.add('dis');
        el.classList.remove('sel');
        if (want.has(i)) el.classList.add('good');
        else if (sel.has(i)) el.classList.add('bad');
      });
      btn.textContent = 'سؤال بعد ←';
      zone.append(fbBlock(good, q.feedback_fa));
    };
    box.append(h('p', { style: 'margin-top:0' }, q.stem_fa), ...opts, btn, zone);
    return;
  }

  /* --- single choice (mcq_single / true_false / matching / ordering / scenario / error_find / rx_read / rx_transcribe) --- */
  renderChoice(q, box, q.options_fa, q.correct_index, true, next, st, fbBlock);
}

function renderChoice(q, box, options, correctIdx, letters, next, st, fbBlock) {
  const marks = ['الف', 'ب', 'ج', 'د', 'هـ', 'و'];
  const zone = h('div', {});
  let answered = false;
  const els = options.map((o, i) => {
    const el = h('div', { class: 'opt' }, h('span', { class: 'mk' }, letters ? marks[i] || '•' : faNum(i + 1)), h('span', {}, o));
    el.onclick = () => {
      if (answered) return;
      answered = true; st.answered++;
      const good = i === correctIdx;
      if (good) st.correct++;
      els.forEach((e2, j) => {
        e2.classList.add('dis');
        if (j === correctIdx) e2.classList.add('good');
        else if (j === i) e2.classList.add('bad');
      });
      zone.append(fbBlock(good, q.feedback_fa));
      btn.textContent = 'سؤال بعد ←';
    };
    return el;
  });
  const btn = h('button', { class: 'btn mt', style: 'width:100%;display:none' }, 'سؤال بعد ←');
  btn.onclick = () => { if (answered) next(); };
  box.append(h('p', { style: 'margin-top:0' }, q.stem_fa), ...els, zone, btn);
}

/* ---------------- drugs (virtualized) ---------------- */
async function viewDrugs() {
  const body = h('div', {}, spinner());
  shell('کتابخانهٔ دارو', body, '۹۶۵ داروی ژنریک');
  try {
    const drugs = await API.drugs();
    let list = drugs;
    const search = h('input', { type: 'search', placeholder: 'جست‌وجو در نام فارسی/انگلیسی یا کد…' });
    const info = h('div', { class: 'small mb' });
    const ROW = 58, VIEW = 640;
    const vw = h('div', { class: 'card pad0 vwrap', style: `height:${VIEW}px;overflow-y:auto` });
    const inner = h('div', {});
    vw.append(inner);
    function draw() {
      const top = Math.max(0, vw.scrollTop - VIEW);
      const i0 = Math.floor(top / ROW), i1 = Math.min(list.length, i0 + Math.ceil((VIEW * 2.5) / ROW));
      inner.style.height = list.length * ROW + 'px';
      inner.replaceChildren(...list.slice(i0, i1).map((d, k) => {
        const el = h('div', { class: 'vitem', style: `top:${(i0 + k) * ROW}px;height:${ROW}px` },
          h('div', { class: 'grow' },
            h('div', { class: 'vname' }, d.name_fa || '—'),
            h('div', { class: 'vsub' }, `${d.name_en} · ${d.atc_code || 'بدون کد'}`)),
          d.high_alert ? h('span', { class: 'tag warn' }, 'پرخطر') : null,
          h('span', { class: 'chev' }, '◂'));
        el.onclick = () => location.hash = `#/drug/${encodeURIComponent(d.id)}`;
        return el;
      }));
      info.textContent = `${faNum(list.length)} دارو از ${faNum(drugs.length)} · فهرست رسمی؛ بدون سقف نمایشی`;
    }
    vw.onscroll = () => requestAnimationFrame(draw);
    search.oninput = () => {
      const t = search.value.trim().toLowerCase();
      list = !t ? drugs : drugs.filter(d =>
        (d.name_fa || '').includes(search.value.trim()) ||
        (d.name_en || '').toLowerCase().includes(t) ||
        (d.atc_code || '').toLowerCase().includes(t));
      vw.scrollTop = 0; draw();
    };
    body.replaceChildren(search, h('div', { class: 'mt' }), info, vw);
    draw();
  } catch (e) { body.replaceChildren(errBox(e)); }
}

async function viewDrug(id) {
  const body = h('div', {}, spinner());
  shell('دارو', body);
  try {
    const drugs = await API.drugs();
    const d = drugs.find(x => x.id === decodeURIComponent(id));
    if (!d) { body.replaceChildren(h('div', { class: 'empty' }, 'دارو پیدا نشد.')); return; }
    const row = (k, v) => v === null || v === undefined || v === '' ? null
      : h('div', { class: 'rowline' }, h('span', { class: 'small' }, k), h('b', { style: 'font-size:.88rem' }, Array.isArray(v) ? v.join(' ← ') : String(v)));
    const flags = [];
    if (d.high_alert) flags.push(h('span', { class: 'tag warn' }, 'پرخطر (نیازمند کنترل مضاعف)'));
    if (d.lasa_group) flags.push(h('span', { class: 'tag err' }, 'نام/ظاهر مشابه — گروه ' + d.lasa_group));
    body.replaceChildren(
      h('div', { class: 'card' },
        h('h1', { style: 'margin:0;font-size:1.2rem' }, d.name_fa),
        h('div', { class: 'small' }, d.name_en),
        flags.length ? h('div', { class: 'flex mt' }, flags) : null),
      h('div', { class: 'card pad0' },
        row('کد رسمی', d.atc_code),
        row('فصل طبقه‌بندی', d.atc_chapter_name),
        row('مسیر گروهی', d.group_path),
        row('فرم‌ها', d.forms),
        row('مسیرهای مصرف', d.routes),
        row('ممنوعیت‌ها', d.contraindicated_in),
        row('نگهداری', d.storage_note),
        row('منبع', (d.source_ids || []).join('، '))),
      h('p', { class: 'small' }, 'فیلدهای خالی یعنی دادهٔ تأییدشده در دسترس نیست (صداقت بر کاملیت). این کارت برای بازشناسی و تطبیق است، نه مشاورهٔ درمانی.'),
      h('p', { class: 'small', style: 'color:var(--dim)' }, DISCLAIMER));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------------- tools ---------------- */
async function viewTools() {
  const body = h('div', {}, spinner());
  shell('ابزار پیشخوان', body);
  try {
    const m = await API.manifest();
    const b = m.banks;
    body.replaceChildren(
      h('div', { class: 'grid2' },
        h('a', { class: 'tile', href: '#/calc' }, h('div', { class: 'ico' }, '🧮'), h('div', { class: 't' }, 'ماشین‌حساب‌ها'), h('div', { class: 's' }, faNum(b.calculators.count) + ' ابزار')),
        h('a', { class: 'tile', href: '#/abbr' }, h('div', { class: 'ico' }, '✍️'), h('div', { class: 't' }, 'اختصارهای نسخه'), h('div', { class: 's' }, faNum(b.abbreviations.count) + ' مورد')),
        h('a', { class: 'tile', href: '#/terms' }, h('div', { class: 'ico' }, '📚'), h('div', { class: 't' }, 'واژگان'), h('div', { class: 's' }, faNum(b.terms.count) + ' واژه')),
        h('a', { class: 'tile', href: '#/scenarios' }, h('div', { class: 'ico' }, '🎭'), h('div', { class: 't' }, 'سناریوهای تمرین'), h('div', { class: 's' }, faNum(b.scenarios.count) + ' سناریو')),
        h('a', { class: 'tile', href: '#/escalation' }, h('div', { class: 'ico' }, '🚦'), h('div', { class: 't' }, 'قواعد ارجاع'), h('div', { class: 's' }, faNum(b.escalation_rules.count) + ' قاعده')),
        h('a', { class: 'tile', href: '#/tips' }, h('div', { class: 'ico' }, '💡'), h('div', { class: 't' }, 'نکته‌های پیشخوان'), h('div', { class: 's' }, faNum(b.tips.count) + ' نکته')),
        h('a', { class: 'tile', href: '#/forms' }, h('div', { class: 'ico' }, '🧴'), h('div', { class: 't' }, 'فرم‌های دارویی'), h('div', { class: 's' }, faNum(b.forms.count) + ' فرم')),
        h('a', { class: 'tile', href: '#/routes' }, h('div', { class: 'ico' }, '🧭'), h('div', { class: 't' }, 'مسیرهای مصرف'), h('div', { class: 's' }, faNum(b.routes.count) + ' مسیر')),
        h('a', { class: 'tile', href: '#/errpat' }, h('div', { class: 'ico' }, '⚠️'), h('div', { class: 't' }, 'الگوهای خطا'), h('div', { class: 's' }, faNum(b.error_patterns.count) + ' الگو')))
    );
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* calculators */
async function viewCalc() {
  const body = h('div', {}, spinner());
  shell('ماشین‌حساب‌ها', body, 'همهٔ اعداد بیمه‌ای: ورودی کاربر');
  try {
    const recs = await API.calcs();
    const zone = h('div', {});
    const pick = h('div', { class: 'flex mb' });
    let cur = recs[0];
    function mount(r) {
      cur = r;
      pick.querySelectorAll('.chip').forEach(c => c.classList.toggle('on', c.dataset.id === r.id));
      zone.replaceChildren(buildCalc(r));
    }
    recs.forEach(r => {
      const c = h('span', { class: 'chip', 'data-id': r.id, onclick: () => mount(r) }, r.name_fa);
      pick.append(c);
    });
    function buildCalc(r) {
      const card = h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 4px;font-size:1rem' }, r.name_fa),
        h('p', { class: 'small', style: 'margin:0 0 10px' }, r.purpose));
      const inputs = r.inputs.map(name => {
        let kind = 'number';
        if (r.id === 'calc:convert' && name.includes('واحد')) kind = 'unit';
        if (kind === 'unit') {
          const sel = h('select', { style: 'width:100%;background:var(--panel2);border:1px solid var(--line);border-radius:10px;color:var(--text);padding:10px;font-family:inherit' });
          [['g', 'گرم (g)'], ['mg', 'میلی‌گرم (mg)'], ['mcg', 'میکروگرم (mcg)'], ['l', 'لیتر (l)'], ['ml', 'میلی‌لیتر (ml)']].forEach(([v, t]) => sel.append(h('option', { value: v }, t)));
          return { name, el: sel, unit: true };
        }
        return { name, el: h('input', { type: 'number', inputmode: 'decimal', step: 'any', placeholder: name }), unit: false };
      });
      inputs.forEach(f => card.append(h('div', { class: 'mb' }, h('div', { class: 'small' }, f.name), f.el)));
      const out = h('div', { class: 'mt' });
      const btn = h('button', { class: 'btn acc', style: 'width:100%' }, 'محاسبه');
      btn.onclick = () => {
        const num = el => parseFloat(String(el.value).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
        try {
          let res;
          const v = inputs.map(f => f.unit ? f.el.value : num(f.el));
          if (r.id === 'calc:qty') res = { val: v[0] * v[1], txt: `${v[0]} × ${v[1]} = ${v[0] * v[1]}` };
          else if (r.id === 'calc:packs') res = { val: Math.ceil(v[0] / v[1]), txt: `${v[0]} ÷ ${v[1]} = ${v[0] / v[1]} → گرد به بالا: ${Math.ceil(v[0] / v[1])}` };
          else if (r.id === 'calc:volume') res = { val: v[0] / v[1], txt: `${v[0]} ÷ ${v[1]} = ${(v[0] / v[1]).toFixed(2)} میلی‌لیتر` };
          else if (r.id === 'calc:days') res = { val: v[0] / v[1], txt: `${v[0]} ÷ ${v[1]} = ${(v[0] / v[1]).toFixed(1)} روز` };
          else if (r.id === 'calc:leftover') res = { val: v[0] - v[1] * v[2], txt: `${v[0]} − (${v[1]} × ${v[2]}) = ${v[0] - v[1] * v[2]}` };
          else if (r.id === 'calc:split') res = { val: v[0] * v[1], txt: `${v[0]} × ${v[1]} = ${v[0] * v[1]}` };
          else if (r.id === 'calc:reorder') res = { val: v[0] * v[1] + v[2], txt: `(${v[0]} × ${v[1]}) + ${v[2]} = ${v[0] * v[1] + v[2]}` };
          else if (r.id === 'calc:convert') {
            const from = v[1], to = v[2], x = v[0];
            const chain = { g: ['mg', 1000], mg: ['mcg', 1000], l: ['ml', 1000] };
            const inv = { mg: ['g', 1000], mcg: ['mg', 1000], ml: ['l', 1000] };
            let val = x, curU = from, path = [x + ' ' + from];
            let guard = 0;
            while (curU !== to && guard++ < 5) {
              if (chain[curU] && chain[curU][0] === to) { val *= chain[curU][1]; curU = to; path.push(val + ' ' + curU); }
              else if (inv[curU] && inv[curU][0] === to) { val /= inv[curU][1]; curU = to; path.push(val + ' ' + curU); }
              else if (chain[curU]) { val *= chain[curU][1]; curU = chain[curU][0]; path.push(val + ' ' + curU); }
              else if (inv[curU]) { val /= inv[curU][1]; curU = inv[curU][0]; path.push(val + ' ' + curU); }
              else break;
            }
            if (curU !== to) throw new Error('این تبدیل پشتیبانی نمی‌شود');
            res = { val, txt: path.join(' ← ') };
          }
          else throw new Error('فرمول این ابزار در اپ پیاده نشده؛ روش: ' + r.method);
          if (!isFinite(res.val)) throw new Error('ورودی نامعتبر');
          out.replaceChildren(h('div', { class: 'fb ok' }, h('h4', {}, 'نتیجه'), h('p', { style: 'margin:4px 0;font-size:1.05rem' }, faNum(String(res.txt))),
            h('div', { class: 'ref' }, 'کنترل معکوس را فراموش نکنید — خروجی ابزار جایگزین دقت شما نیست.')));
        } catch (e2) {
          out.replaceChildren(h('div', { class: 'fb no' }, h('h4', {}, 'روش این ابزار'), h('p', { style: 'margin:4px 0' }, r.method), h('p', { class: 'small' }, 'مثال: ' + r.example)));
        }
      };
      card.append(btn, out);
      card.append(h('p', { class: 'small mt' }, 'روش: ' + r.method + (r.example ? ' · مثال: ' + r.example : '')));
      return card;
    }
    mount(cur);
    body.replaceChildren(pick, zone,
      h('p', { class: 'small' }, 'سیاست: هیچ عدد بیمه‌ای از حافظه نمی‌آید؛ درصدها همواره ورودی کاربر یا سامانهٔ رسمی‌اند.'));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* generic list views */
async function listView(title, crumb, loader, rowFn, searchFn) {
  const body = h('div', {}, spinner());
  shell(title, body, crumb);
  try {
    const recs = await loader();
    let list = recs;
    const search = searchFn ? h('input', { type: 'search', placeholder: 'جست‌وجو…', class: 'mb' }) : null;
    const box = h('div', { class: 'card pad0' });
    const info = h('div', { class: 'small mb' });
    function draw() {
      info.textContent = faNum(list.length) + ' مورد از ' + faNum(recs.length);
      box.replaceChildren(...list.map(rowFn));
    }
    if (search) search.oninput = () => { list = searchFn(recs, search.value.trim()); draw(); };
    body.replaceChildren(search, info, box);
    draw();
  } catch (e) { body.replaceChildren(errBox(e)); }
}
const norm = s => String(s || '').toLowerCase();
function viewAbbr() {
  return listView('اختصارهای نسخه', 'مرجع علائم و اختصارها', API.abbr,
    r => h('div', { class: 'rowline' },
      h('div', {}, h('b', {}, r.symbol), h('div', { class: 'small' }, r.fa),
        r.note ? h('div', { class: 'small', style: 'color:var(--warn)' }, '⚠ ' + r.note) : null),
      r.risk ? h('span', { class: 'tag err' }, r.risk) : null),
    (recs, t) => recs.filter(r => norm(r.symbol).includes(t.toLowerCase()) || norm(r.fa).includes(t) || norm(r.en).includes(t.toLowerCase())));
}
function viewTerms() {
  return listView('واژگان', 'فرهنگ واژه‌های نسخه‌خوانی', API.terms,
    r => h('div', { class: 'rowline' },
      h('div', {}, h('b', {}, r.fa), h('span', { class: 'small' }, ' — ' + r.en), h('div', { class: 'small' }, r.def)),
      h('span', { class: 'tag' }, r.ch || '')),
    (recs, t) => recs.filter(r => norm(r.fa).includes(t) || norm(r.en).includes(t.toLowerCase()) || norm(r.def).includes(t)));
}
function viewScenarios() {
  return listView('سناریوهای تمرین', 'تمرین‌های میزِ پیشخوان', API.scenarios,
    r => h('div', { style: 'padding:12px 14px;border-bottom:1px solid var(--line)' },
      h('div', { class: 'flex mb' }, h('b', {}, r.title), h('span', { class: 'tag' }, 'سطح ' + faNum(r.level)), h('span', { class: 'tag' }, r.ch)),
      h('div', { class: 'small' }, 'صحنه: ' + r.setup),
      h('div', { class: 'small' }, 'وظیفه: ' + r.task),
      h('div', { class: 'small', style: 'color:var(--ok)' }, 'معیار: ' + r.check)),
    (recs, t) => recs.filter(r => norm(r.title).includes(t) || norm(r.setup).includes(t)));
}
async function viewEsc() {
  return listView('قواعد ارجاع', 'کِی متوقف کنیم و به داروساز بسپاریم', API.esc,
    r => h('div', { class: 'rowline' },
      h('div', {}, h('b', { style: 'font-size:.88rem' }, r.trigger), h('div', { class: 'small' }, r.action)),
      h('span', { class: 'tag ' + (r.urg === 'now' ? 'err' : 'warn') }, r.urg === 'now' ? 'فوری' : 'ثبت')),
    (recs, t) => recs.filter(r => norm(r.trigger).includes(t) || norm(r.action).includes(t)));
}
function viewTips() {
  return listView('نکته‌های پیشخوان', 'عادت‌های ایمن روزمره', API.tips,
    r => h('div', { class: 'rowline' },
      h('div', {}, h('b', {}, '💡 ' + r.t), h('div', { class: 'small' }, r.b)),
      h('span', { class: 'tag' }, r.ch || '')),
    (recs, t) => recs.filter(r => norm(r.t).includes(t) || norm(r.b).includes(t)));
}
function viewForms() {
  return listView('فرم‌های دارویی', 'فهرست استاندارد فرم‌ها', API.forms,
    r => h('div', { class: 'rowline' },
      h('div', {}, h('b', {}, r.name_fa), h('div', { class: 'small' }, r.name_en)),
      h('span', { class: 'tag' }, r.form_class)),
    (recs, t) => recs.filter(r => norm(r.name_fa).includes(t) || norm(r.name_en).includes(t.toLowerCase())));
}
function viewRoutes() {
  return listView('مسیرهای مصرف', 'فهرست استاندارد مسیرها', API.routes,
    r => h('div', { class: 'rowline' },
      h('div', {}, h('b', {}, r.name_fa), h('div', { class: 'small' }, r.name_en)),
      h('span', { class: 'tag' }, r.route_class || '')),
    (recs, t) => recs.filter(r => norm(r.name_fa).includes(t) || norm(r.name_en).includes(t.toLowerCase())));
}
function viewErrPat() {
  return listView('الگوهای خطا', 'خطاهای کلاسیک پیشخوان', API.errpat,
    r => h('div', { style: 'padding:12px 14px;border-bottom:1px solid var(--line)' },
      h('b', {}, r.title_fa || r.id),
      r.mechanism_fa ? h('div', { class: 'small' }, 'مکانیزم: ' + r.mechanism_fa) : null,
      r.defense_fa ? h('div', { class: 'small', style: 'color:var(--ok)' }, 'دفاع: ' + r.defense_fa) : null),
    (recs, t) => recs.filter(r => norm(JSON.stringify(r)).includes(t.toLowerCase())));
}

/* ---------------- rx vault (zero-image by policy) ---------------- */
async function viewRx() {
  const body = h('div', {});
  shell('گنجینهٔ نسخه', body, 'صفر تصویر — سیاست قطعی');
  try {
    const m = await API.manifest();
    const rx = m.banks.prescriptions;
    const local = JSON.parse(localStorage.getItem('rx-academy-local-rx') || '[]');
    const file = h('input', { type: 'file', accept: '.json,application/json', style: 'display:none' });
    file.onchange = async () => {
      try {
        const txt = await file.files[0].text();
        const j = JSON.parse(txt);
        const arr = Array.isArray(j) ? j : [j];
        local.push(...arr.map(r => ({ ...r, _imported_at: new Date().toISOString() })));
        localStorage.setItem('rx-academy-local-rx', JSON.stringify(local));
        location.reload();
      } catch (e2) { alert('فایل JSON معتبر نبود.'); }
    };
    body.replaceChildren(
      h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 8px' }, '🗂️ گنجینهٔ نسخه — وضعیت صادقانه'),
        h('p', { class: 'small' }, 'طبق سیاست پروژه (خط قرمز ۱)، هیچ نسخه‌ای بازسازی یا شبیه‌سازی نمی‌شود. نسخه فقط بایت‌به‌بایت از منابع ثبت‌شده وارد می‌شود. امروز:'),
        h('div', { class: 'flex mb' },
          h('span', { class: 'tag ' + (rx.count > 0 ? 'acc' : 'warn') }, `منابع رسمی: ${faNum(rx.count)} از کف ${faNum(rx.floor)}`),
          h('span', { class: 'tag' }, `واردشدهٔ محلی: ${faNum(local.length)}`)),
        rx.count === 0 ? h('p', { class: 'small', style: 'color:var(--warn)' }, 'میزبان‌های رسمی نسخه‌های الکترونیک از این محیط قابل دسترسی نبودند (مستند در KNOWN_GAPS). موتور، بیننده و واردسازی کامل است؛ بانک خالی است.') : null),
      h('div', { class: 'card' },
        h('b', {}, 'موتور آماده است'),
        h('ul', { class: 'small' },
          h('li', {}, 'بینندهٔ نسخه با لایه‌های نمایش/بزرگ‌نمایی (برای تصاویر واردشده)'),
          h('li', {}, 'هش ورودی با ثبت هش فایل و منبع'),
          h('li', {}, 'برچسب‌گذاری و پاسخ‌نامه با وضعیت «تأییدنشده» برای کلیدهای ناخوانا')),
        h('button', { class: 'btn acc', onclick: () => file.click() }, 'واردسازی فایل نسخه (JSON)'), file),
      local.length ? h('div', { class: 'card pad0' },
        h('div', { class: 'rowline' }, h('b', {}, 'نسخه‌های واردشدهٔ محلی')),
        ...local.map((r, i) => h('div', { class: 'rowline' },
          h('div', {}, h('b', { style: 'font-size:.86rem' }, r.title_fa || r.id || ('نسخهٔ ' + faNum(i + 1))),
            h('div', { class: 'small' }, (r.note_fa || '') + ' · ' + (r._imported_at || '').slice(0, 10))),
          h('span', { class: 'tag' }, r.status || 'خام')))) : null);
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------------- search ---------------- */
async function viewSearch() {
  const body = h('div', {});
  shell('جست‌وجو', body);
  const inp = h('input', { type: 'search', placeholder: 'نام دارو، اختصار، واژه یا عنوان صفحه…', autofocus: true });
  const res = h('div', {});
  body.replaceChildren(inp, res);
  let timer;
  inp.oninput = () => { clearTimeout(timer); timer = setTimeout(run, 220); };
  async function run() {
    const t = inp.value.trim();
    if (t.length < 2) { res.replaceChildren(h('div', { class: 'empty' }, 'حداقل دو حرف بنویسید.')); return; }
    res.replaceChildren(spinner('در حال جست‌وجو…'));
    try {
      const [drugs, abbr, terms, cur] = await Promise.all([API.drugs(), API.abbr(), API.terms(), API.curriculum()]);
      const tl = t.toLowerCase();
      const dHits = drugs.filter(d => norm(d.name_fa).includes(t) || norm(d.name_en).includes(tl) || norm(d.atc_code).includes(tl)).slice(0, 30);
      const aHits = abbr.filter(r => norm(r.symbol).includes(tl) || norm(r.fa).includes(t)).slice(0, 20);
      const tHits = terms.filter(r => norm(r.fa).includes(t) || norm(r.en).includes(tl) || norm(r.def).includes(t)).slice(0, 20);
      const pHits = [];
      for (const ch of cur.chapters) {
        const sh = await API.chapter(ch.id);
        for (const p of sh.pages) if (norm(p.title_fa).includes(t)) pHits.push({ p, ch });
        if (pHits.length >= 15) break;
      }
      const sec = (title, items, rowFn) => items.length ? h('div', { class: 'mb' }, h('div', { class: 'small mb' }, `${title} (${faNum(items.length)})`), h('div', { class: 'card pad0' }, items.map(rowFn))) : null;
      res.replaceChildren(...[
        sec('دارو', dHits, d => {
          const r = h('div', { class: 'rowline click' }, h('div', {}, h('b', { style: 'font-size:.88rem' }, d.name_fa), h('div', { class: 'small' }, d.name_en)), h('span', { class: 'chev' }, '◂'));
          r.onclick = () => location.hash = '#/drug/' + encodeURIComponent(d.id); return r;
        }),
        sec('اختصار', aHits, r => h('div', { class: 'rowline' }, h('div', {}, h('b', {}, r.symbol), h('div', { class: 'small' }, r.fa)))),
        sec('واژه', tHits, r => h('div', { class: 'rowline' }, h('div', {}, h('b', {}, r.fa), h('div', { class: 'small' }, r.def)))),
        sec('صفحهٔ کتابچه', pHits, x => {
          const r = h('div', { class: 'rowline click' }, h('div', {}, h('b', { style: 'font-size:.88rem' }, x.p.title_fa), h('div', { class: 'small' }, x.ch.title_fa)), h('span', { class: 'chev' }, '◂'));
          r.onclick = () => location.hash = `#/book/${x.ch.id}/${x.p.id}`; return r;
        }),
        (!dHits.length && !aHits.length && !tHits.length && !pHits.length) ? h('div', { class: 'empty' }, 'چیزی پیدا نشد.') : null
      ].filter(Boolean));
    } catch (e) { res.replaceChildren(errBox(e)); }
  }
}

/* ---------------- about / honesty ---------------- */
async function viewAbout() {
  const body = h('div', {}, spinner());
  shell('درباره و صداقت', body);
  try {
    const m = await API.manifest();
    const srcs = await API.sources();
    const rows = Object.entries(m.banks).map(([k, v]) =>
      h('tr', {}, h('td', {}, k), h('td', {}, faNum(v.count ?? 0)), h('td', {}, faNum(v.floor ?? '—')),
        h('td', {}, (v.count ?? 0) >= (v.floor ?? 0) ? '✅' : '⚠️ در حال تکمیل/شکاف مستند')));
    body.replaceChildren(
      h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 6px;font-size:1.05rem' }, 'RX-ACADEMY چیست؟'),
        h('p', { class: 'small' }, 'اپ آفلاین و لوکال‌فرست برای آموزش «نسخه‌خوانی و کار در داروخانه» — فارسی و راست‌چین، بدون سرور، بدون ورود، بدون تحلیل رفتار. مخاطب: تکنسین پیشخوان (سقف عمق: بازشناسی، رمزگشایی، محاسبهٔ ساده، کنترل خطا، برچسب‌گذاری، تحویل، ارجاع).'),
        h('p', { class: 'small' }, 'خط قرمزها: هیچ نسخهٔ جعلی تولید نمی‌شود؛ هیچ منبع/آمار/برند ساختگی‌ای در داده نیست؛ فیلد بدون منبع = خالی (و پنهان در رابط).')),
      h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 8px;font-size:1.05rem' }, 'کف‌های کمّی در برابر واقعیت'),
        h('div', { style: 'overflow-x:auto' }, h('table', { class: 'mini' }, h('thead', {}, h('tr', {}, h('th', {}, 'بانک'), h('th', {}, 'واقعی'), h('th', {}, 'کف'), h('th', {}, 'وضعیت'))), h('tbody', {}, rows)))),
      h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 8px;font-size:1.05rem' }, 'منابع ثبت‌شده'),
        h('p', { class: 'small' }, `${faNum(srcs.length)} منبع در منابع پروژه ثبت شده است؛ فهرست کامل در فایل منابع و گزارش اکتساب (درون بستهٔ تحویل).`)),
      h('div', { class: 'card' },
        h('h2', { style: 'margin:0 0 8px;font-size:1.05rem' }, 'محدودیت‌های نقش'),
        h('p', { class: 'small' }, 'این اپ جایگزین داروساز نیست؛ هیچ توصیهٔ درمانی، تنظیم دوز یا تفسیر آزمایش ارائه نمی‌دهد و در همهٔ محتوا، مسیر «توقف و ارجاع» آموزش داده می‌شود.'),
        h('p', { class: 'small', style: 'color:var(--dim)' }, DISCLAIMER)));
  } catch (e) { body.replaceChildren(errBox(e)); }
}

/* ---------------- router ---------------- */
const routes = [
  [/^#?\/?$/, viewHome],
  [/^#\/book$/, viewBook],
  [/^#\/book\/(C\d+)\/([\w-]+)$/, (m) => viewPage(m[1], m[2])],
  [/^#\/quiz$/, viewQuiz],
  [/^#\/quiz\/(C\d+)$/, m => viewQuizChapter(m[1])],
  [/^#\/drugs$/, viewDrugs],
  [/^#\/drug\/(.+)$/, m => viewDrug(m[1])],
  [/^#\/tools$/, viewTools],
  [/^#\/calc$/, viewCalc],
  [/^#\/abbr$/, viewAbbr],
  [/^#\/terms$/, viewTerms],
  [/^#\/scenarios$/, viewScenarios],
  [/^#\/escalation$/, viewEsc],
  [/^#\/tips$/, viewTips],
  [/^#\/forms$/, viewForms],
  [/^#\/routes$/, viewRoutes],
  [/^#\/errpat$/, viewErrPat],
  [/^#\/rx$/, viewRx],
  [/^#\/search$/, viewSearch],
  [/^#\/about$/, viewAbout]
];
function route() {
  const hash = location.hash || '#/';
  for (const [re, fn] of routes) {
    const m = hash.match(re);
    if (m) return fn(m);
  }
  viewHome();
}
window.addEventListener('hashchange', route);
window.addEventListener('DOMContentLoaded', () => {
  route();
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
});
