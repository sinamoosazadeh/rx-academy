# گزارش اکتساب — `ACQUISITION_LOG.md`

> یک سطر به ازای هر فایل دریافت‌شده (`IMG-05` بند ۱، `SRC-08`). همهٔ دریافت‌ها با کلاینت `curl` و رعایت فاصلهٔ ≥۱٫۵ ثانیه بین درخواست‌ها به یک میزبان. تاریخ: ۲۰۲۶-۰۹-۳۰. هیچ دورزدنی (نسخه‌موبایل جعلی، تغییر هدر هویت برای عبور از 403) انجام **نشد**.

| # | منبع (`source_id`) | URL | نتیجه | بایت | sha256 | محل ذخیره |
|---|---|---|---|---|---|---|
| 1 | `src-irandataportal-budget1399` | https://irandataportal.syr.edu/wp-content/uploads/law-1399.pdf | HTTP 200 | ۱۴٬۵۷۷٬۴۹۰ | `aa4bc808bcef7167038f9cd627c9f7704017c6906a8baab250e44db4efe8ce1b` | `inputs/pdfs/law-budget-1399.pdf` |
| 2 | `src-ipharm-taeed` | https://ipharm.ir/wp-content/uploads/2017/06/فایل-آموزشی-تایید-دارو.pdf | HTTP 200 | ۵٬۶۳۳٬۷۸۹ | `688222fe6401c62f512a88695d8fef47f55940e23e3b8c1345b85db116f8b832` | `inputs/pdfs/ipharm-taeed-daroo-2017.pdf` |
| 3 | `src-tbzmed-mj` | https://mj.tbzmed.ac.ir/PDF/mj-47-412.pdf | HTTP 200 | ۶۵۸٬۳۹۲ | `8f1dfb47c93cf5d9a0c97e4c968d46bfd49e5df6fa4a06a39c93750147e2` | `inputs/pdfs/mj-tbzmed-47-412.pdf` |
| 4 | `src-semanticscholar-controlled` | https://pdfs.semanticscholar.org/6d27/d734771902a70e0a97702880a96419ff2fc4.pdf | HTTP 200 | ۲۱۳٬۲۵۴ | `41294863ec62291446efa568593bf1609a98db9bef4bc916b7986423396e1683` | `inputs/pdfs/controlled-substances-monitoring-paper.pdf` |
| 5 | `src-ismp-highalert` | https://www.ismp.org/system/files/resources/2021-09/HighAlertMedications_Community-2021.pdf | HTTP 200 | ۶۱٬۳۲۵ | `41a124668da916d6d1d37285ad89895106e7e148eda4aeec5ad9f6b2b4d81faf` | `inputs/pdfs/ismp-high-alert-community-2021.pdf` |
| 6 | `src-ismp-newsletter-2024` | https://www.ismp.org/sites/default/files/attachments/2024-01/20240111.pdf | HTTP 200 | ۹۹۰٬۶۰۹ | `8f43373b4ef8f7e6e6d065b809bfe46380ade204f35e01b518824b44641fa6ca` | `inputs/pdfs/ismp-newsletter-2024-01-11-high-alert-acute.pdf` |
| 7 | `src-ismp-abbr` | https://www.ismp.org/recommendations/error-prone-abbreviations-list | HTTP 200 | ۱۲۰٬۳۸۷ | `3223ecbfa97d4ec1817f7b3d9d11dafa95d686886692e2f0e73a121ad71db9fc` | `inputs/notes/ismp-error-prone-abbreviations.html` |
| 8 | `src-who-eml` | https://www.who.int/groups/expert-committee-on-selection-and-use-of-essential-medicines/essential-medicines-lists | HTTP 200 | ۹۱٬۸۹۸ | `fa222a7ccda419b700e7ec2b6fa888b65385b02832a745a41d555299df433762` | `inputs/notes/who-eml-lists-page.html` |
| 9 | `src-who-atc` | https://www.whocc.no/atc_ddd_index/ | HTTP 200 | ۱۴٬۴۶۱ | `0d908251da9b5825616c679096d2742048a27436522593f29f63eba2f0480a05` | `inputs/notes/atc-pages/*.html` (۱٬۳۱۸ صفحه) + `data/raw/atc-index.json` | نمایهٔ کامل رسمی ثبت داروها — پیمایش بازگشتی رسمی (فصل→گروه→ماده) | 5678 ماده + ۱٬۳۱۸ گره گروهی | `9b90a8c795de6504…` (advisory) | ✅ رسمی، مستقیم |
| `inputs/notes/whocc-atc-index.html` |

**تلاش‌های ناموفق (ثبت صادقانه):**
- `who-eml` — بیت‌استریم مستقیم `iris.who.int` برای خودکار: **403** (دور زده نشد؛ فقط صفحهٔ فهرست‌ها ثبت شد).
- `src-tehranva-label` — خطای **500** از سرور مقصد.
- `fa.healthcarestudies.com`, `pharmacytech.blogfa.com`, `darousara.blogfa.com`, `paperity.org` — **403** برای کلاینت خودکار.
- همهٔ میزبان‌های `.ir` داخلی به‌جز فهرست‌های زیر — **اتصال برقرار نشد (000)**: جزئیات در `SOURCE_TRIAGE.md`.
- `src-tbzmed-mj` — فایل سالم دریافت شد ولی لایهٔ متن با پارسر موجود باز نشد (خطای بازگشت); در فاز ۴ با ابزار دیگر بازخوانی یا به «نیازمند بازبینی» منتقل می‌شود.
- `law-budget-1399.pdf` — فایل **تصویری/اسکنی** است (فقط واترمارک از متن استخراج شد؛ ۱۳۸ نویسه در ۶ صفحهٔ نخست). بدون متن قابل‌استفاده تا بازبینی انسانی؛ از آن محتوایی استخراج **نمی‌شود**.
