/* RX-ACADEMY service worker — offline-first, versioned caches, no external requests */
'use strict';
const SHELL_CACHE = 'rx-shell-v4';
const DATA_CACHE = 'rx-data-v4';
const SHELL_ASSETS = [
  './', './index.html', './manifest.webmanifest', './data/app-files.json',
  './app/app.js', './app/styles.css', './app/icon.svg',
  './app/icon-192.png', './app/icon-512.png'
];
self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const c = await caches.open(SHELL_CACHE);
    await c.addAll(SHELL_ASSETS);
    // پیش‌کش کامل داده‌ها و کتابچه برای آفلاین صددرصد پس از نصب
    try {
      const res = await fetch('./data/app-files.json', { cache: 'no-store' });
      if (res.ok) {
        const list = (await res.json()).files.map(f => './' + f);
        await Promise.all(list.map(async u => {
          try {
            const r = await fetch(u);
            if (r && r.ok) await c.put(u, r);
          } catch (err) { /* فایل تکی ناموفق، کش را خراب نمی‌کند */ }
        }));
      }
    } catch (err) { /* فهرست موجود نبود؛ فقط شل کش می‌شود */ }
    self.skipWaiting();
  })());
});
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== SHELL_CACHE && k !== DATA_CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('message', e => { if (e.data === 'skipWaiting') self.skipWaiting(); });
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // fully local app
  const path = url.pathname;
  const isShell = SHELL_ASSETS.some(a => path.endsWith(a.replace('./', ''))) || path.endsWith('/') || path.endsWith('index.html');
  const cacheName = isShell ? SHELL_CACHE : DATA_CACHE;
  e.respondWith(
    caches.open(cacheName).then(async c => {
      const hit = await c.match(req);
      const network = fetch(req).then(res => {
        if (res && res.ok) c.put(req, res.clone());
        return res;
      }).catch(() => null);
      if (hit) return hit;
      const net = await network;
      if (net) return net;
      if (req.mode === 'navigate') return (await caches.match('./index.html')) || Response.error();
      return Response.error();
    })
  );
});
